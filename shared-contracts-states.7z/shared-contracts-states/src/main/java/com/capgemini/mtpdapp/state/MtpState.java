package com.capgemini.mtpdapp.state;



import net.corda.core.contracts.LinearState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import org.jetbrains.annotations.NotNull;

import java.util.*;


public class MtpState implements LinearState {
    private final Party borrower;
    private final Party lender;
    private final Integer value;
    private final UniqueIdentifier linearId;

    public MtpState(Party borrower, Party lender, Integer value, UniqueIdentifier linearId) {
        this.borrower = borrower;
        this.lender = lender;
        this.value = value;
        this.linearId = linearId;
    }

    public Party getBorrower() {
        return borrower;
    }

    public Party getLender() {
        return lender;
    }

    public Integer getValue() {
        return value;
    }

    @NotNull
    @Override
    public UniqueIdentifier getLinearId() {
        return linearId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MtpState mtpState = (MtpState) o;
        return borrower.equals(mtpState.borrower) &&
                lender.equals(mtpState.lender) &&
                value.equals(mtpState.value) &&
                linearId.equals(mtpState.linearId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(borrower, lender, value, linearId);
    }

    @Override
    public String toString() {
        return "MtpState{" +
                "borrower=" + borrower +
                ", lender=" + lender +
                ", value=" + value +
                ", linearId=" + linearId +
                '}';
    }

    //Modified for upgrading to Release to Version 13
    @Override
    public List<AbstractParty> getParticipants() {

        return Arrays.asList(
                lender, borrower
        );
    }


}