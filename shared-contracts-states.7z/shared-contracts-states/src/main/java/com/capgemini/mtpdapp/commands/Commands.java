package com.capgemini.mtpdapp.commands;

import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.TypeOnlyCommandData;

/**
 * Standalone commands interface which is required to add signature for notary to be validate
 * (Note - this could be change in future)
 */
public interface Commands extends CommandData {

    class Create extends TypeOnlyCommandData implements Commands {
    }

    class Amend extends TypeOnlyCommandData implements Commands {
    }
}
