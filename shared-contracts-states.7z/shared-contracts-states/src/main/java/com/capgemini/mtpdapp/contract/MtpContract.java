package com.capgemini.mtpdapp.contract;

import net.corda.core.contracts.CommandData;
import com.capgemini.mtpdapp.state.MtpState;
import net.corda.core.contracts.CommandWithParties;
import net.corda.core.contracts.Contract;
import net.corda.core.identity.AbstractParty;
import net.corda.core.transactions.LedgerTransaction;
import java.security.PublicKey;
import java.util.HashSet;
import java.util.Set;
import static java.util.stream.Collectors.toList;
import static net.corda.core.contracts.ContractsDSL.requireSingleCommand;
import static net.corda.core.contracts.ContractsDSL.requireThat;

public class MtpContract implements Contract {
    public static final String MTP_CONTRACT_ID = "com.capgemini.mtpdapp.contract";

    @Override
    public void verify(LedgerTransaction tx) {
        final CommandWithParties<Commands> command = requireSingleCommand(tx.getCommands(), Commands.class);
        final Commands commandData = command.getValue();
        final Set<PublicKey> setOfSigners = new HashSet<>(command.getSigners());

        if (commandData instanceof Commands.Create) {
            verifyCreate(tx, setOfSigners);
        } else {
            throw new IllegalArgumentException("Unrecognised command.");
        }
    }
    // This only allows one obligation issuance per transaction.
    private void verifyCreate(LedgerTransaction tx, Set<PublicKey> signers)
    {
        final CommandWithParties<Commands.Create> command = requireSingleCommand(tx.getCommands(), Commands.Create.class);

        requireThat(require -> {

            final MtpState out = tx.outputsOfType(MtpState.class).get(0);

            // Generic constraints around Mtp transaction.
            require.using("No Inputs Should Be Consumed When Initiating a Transaction.",
                    tx.getInputStates().isEmpty());
            require.using("Only One Output State Should Be Created For Each Transaction.",
                    tx.getOutputStates().size() == 1);
            require.using("All of the participants must be signers.", command.getSigners().containsAll(out.getParticipants().stream().map(AbstractParty::getOwningKey).collect(toList())));
           //MTP specific constraints
            require.using("The lender and the borrower cannot be the same entity.",
                    out.getLender() != out.getBorrower());
            require.using("The lending value must be non-negative.",
                    out.getValue() > 0);


            return null;
        });
    }
    public interface Commands extends CommandData {
        class Create implements Commands {}
    }

}