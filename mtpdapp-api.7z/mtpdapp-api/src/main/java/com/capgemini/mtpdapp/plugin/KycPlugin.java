package com.capgemini.mtpdapp.plugin;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.h2.jdbc.JdbcSQLException;
import org.jetbrains.annotations.NotNull;

import net.corda.core.contracts.Contract;
import net.corda.core.flows.IllegalFlowLogicException;
import net.corda.core.serialization.SerializationWhitelist;

// Serialization whitelist.
public class KycPlugin implements SerializationWhitelist {
    @NotNull
    @Override
    public List<Class<?>> getWhitelist() {

        List<Class<?>> whiteList = new ArrayList<Class<?>>();
        whiteList.add(Date.class);
        whiteList.add(IllegalArgumentException.class);
        whiteList.add(IllegalFlowLogicException.class);
        whiteList.add(Contract.class);
        whiteList.add(JdbcSQLException.class);

        return whiteList;
    }


}