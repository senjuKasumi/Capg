package com.capgemini.controller;

import com.capgemini.corda.user.AppUser;
import com.capgemini.serviceimpl.MtpServiceImpl;
import net.corda.core.identity.CordaX500Name;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.util.concurrent.ExecutionException;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

//import javax.xml.ws.Response;

@RestController
@CrossOrigin
@RequestMapping("/api/")
public class MTPController {
	@Autowired
	private MtpServiceImpl mtpServiceImpl;

	public boolean setAppUser(HttpSession session, String userID) {
		if(session != null) {
			System.out.println("MTPController >> the user "+userID);
			AppUser appUser = (AppUser) session.getAttribute(userID);
			System.out.println("MTPController >> checking whether session has the logged in user : "+appUser.getUserId());
			if(appUser != null) {
				mtpServiceImpl.setAppUser(appUser);
				return true;
			}
		}
		return false;
	}

	@RequestMapping(value = "{userId}/createTransaction", method = RequestMethod.PUT)
	public Response createTransaction(@RequestParam("value") Integer value, @RequestParam("partyName") CordaX500Name partyName, @PathVariable("userId") String userID, HttpServletRequest request)
			throws InterruptedException, ExecutionException {
		if (value <= 0) {
			return Response.status(BAD_REQUEST).entity("Value must be non-negative.\n").build();
		}

		/*if (partyName == null) {
			return Response.status(BAD_REQUEST).entity("partyName missing or has wrong format.\n").build();
		}*/
		/*else
			return Response.status(BAD_REQUEST).entity("asdf").build();*/

		if(this.setAppUser(request.getSession(false), userID)) {
			return mtpServiceImpl.createTransaction(value, partyName);
		}
		return null;
	}






/*


	@RequestMapping(value = "{flag}/kyc/all/{bankName}/{userID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchAllKyc(@PathVariable("flag") String flag,@PathVariable("bankName") String bankName,@PathVariable("userID") String userID,
            HttpServletRequest request) {

		Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.searchAllKyc(flag, bankName,userID);
			}
		} else {
			customResponse = kycFabricService.searchAllKyc(flag, bankName,userID);
		}
		return customResponse;
	}



	@RequestMapping(value = "{flag}/kycByUserId/{userId}/{bankName}/{consumerUserID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchUserByUserId(@PathVariable("userId") String userId, @PathVariable("flag") String flag,
									 @PathVariable("bankName") String bankName,@PathVariable("consumerUserID") String consumerUserID,
	                                    HttpServletRequest request) {
		Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userId)) {
				customResponse = mtpServiceImpl.searchUserByUserId(userId, flag, bankName, consumerUserID);
			}
			
		} else {
			customResponse = kycFabricService.searchUserByUserId(userId, flag, bankName, consumerUserID);
		}
		return customResponse;
	}



	@RequestMapping(value = "{flag}/kycByBankName/{bankName}/{userID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchUserByBankName(@PathVariable("bankName") String bankName, @PathVariable("flag") String flag,@PathVariable("userID") String userID,
            HttpServletRequest request) {
		
		Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.searchUserByBankName(bankName,flag,userID);
			}
			
		} else {
			customResponse = kycFabricService.searchUserByBankName(bankName,flag,userID);
		}
		return customResponse;
	}

	@RequestMapping(value = "{flag}/updateKycDoc/{userID}", method = RequestMethod.POST)
	public CustomResponse updateDocument(@RequestBody UserKycInfoDTO userInfo, @PathVariable("flag") String flag,@PathVariable("userID") String userID,
            HttpServletRequest request) {
		
		CustomResponse customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.updateDocument(userInfo, flag, userID);
			}
			
		} else {
			customResponse = kycFabricService.updateDocument(userInfo, flag,userID);
		}
		return customResponse;
	}

	@RequestMapping(value = "{flag}/kyc/counts/{bankName}/{userID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchKYCCounts(@PathVariable("flag") String flag, @PathVariable("bankName") String bankName,@PathVariable("userID") String userID,
            HttpServletRequest request) {
		
		Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.searchKYCCounts(flag, bankName,userID);
			}
			
		} else {
			customResponse = kycFabricService.searchKYCCounts(flag, bankName,userID);
		}
		return customResponse;
	}


    @RequestMapping(value = "{flag}/kycByCreatedMonth/{bankName}/{userID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchKYCByCreatedMonth(@PathVariable("flag") String flag,@PathVariable("bankName") String bankName,@PathVariable("userID") String userID,
            HttpServletRequest request) {
    	
    	Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.searchKYCByCreatedMonth(flag, bankName,userID);
			}
    		
    	} else {
    		customResponse = kycFabricService.searchKYCByCreatedMonth(flag, bankName,userID);
    	}
		return customResponse;
	}

	@RequestMapping(value = "{flag}/kycByExpiringMonth/{bankName}/{userID}", method = RequestMethod.POST, produces = "application/json")
	public Object searchKYCByExpiringMonth(@PathVariable("flag") String flag,
			@PathVariable("bankName") String bankName,@PathVariable("userID") String userID,
            HttpServletRequest request) {
		
		Object customResponse = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userID)) {
				customResponse = mtpServiceImpl.searchKYCByExpiringMonth(flag, bankName,userID);
			}
			
		} else {
			customResponse = kycFabricService.searchKYCByExpiringMonth(flag, bankName,userID);
		}
		return customResponse;
	}


	@RequestMapping(value = "{flag}/downloadDoc/{userId}/{docName}/{docHash}", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downloadDoc(
			@PathVariable("flag") String flag,
			@PathVariable("userId") String userId,
			@PathVariable("docName") String docName,
			@PathVariable("docHash") String docHash,
            HttpServletRequest request

	) {
		ResponseEntity<byte[]> responseEntity = null;
		System.out.println("MTPController >> downloadDoc: userId-"+userId);
		byte[] docBytes = null;
		if (flag.equalsIgnoreCase("c")) {
			if(this.setAppUser(request.getSession(false), userId)) {
				docBytes = mtpServiceImpl.getKYCAttachedDoc(flag, userId, docHash);
			}
			
		} else {
			docBytes = kycFabricService.getKYCAttachedDoc(flag, userId, docHash);
		}
		
		if(docBytes != null){

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(org.springframework.http.MediaType.parseMediaType("application/octet-stream"));
			headers.add("Content-Disposition", "attachment; filename="+docName+".zip");
			headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

			responseEntity = new ResponseEntity<byte[]>(docBytes, headers, HttpStatus.OK);
		}

		return responseEntity;
	}
*/
}
