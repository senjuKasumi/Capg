package com.capgemini.controller;

import com.capgemini.corda.user.AppUser;
import com.capgemini.model.CustomResponse;
import com.capgemini.model.LoginDetails;
import com.capgemini.service.UserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/login")
@CrossOrigin
public class UserLoginController {

    @Autowired
    private UserLoginService userLoginService;

    @RequestMapping(value = "/check",method = RequestMethod.POST)
    public CustomResponse validateLogin(@RequestBody LoginDetails loginDetails, HttpServletRequest request){
        CustomResponse customResponse = userLoginService.validateLogin(loginDetails);
        HttpSession session = request.getSession(true);
        System.out.println("UserLoginController >> Creating session for the user..");
        session.setAttribute(loginDetails.getUserId(), userLoginService.getAppUser(loginDetails.getUserId()));
        return customResponse;
    }

    @RequestMapping(value = "/role",method = RequestMethod.GET)
    public String checkRole(@RequestBody LoginDetails loginDetails, HttpServletRequest request){
        String role = userLoginService.checkRole(loginDetails);
        return role;
    }

    @RequestMapping(value = "/logout/{flag}/{userId}",method = RequestMethod.GET)
    public CustomResponse logout(@PathVariable("flag") String flag, @PathVariable("userId") String userId, HttpServletRequest request){

        CustomResponse customResponse = new CustomResponse();

        if (flag.equalsIgnoreCase("c")) {
        	HttpSession session = request.getSession(false);
        	if(session != null && session.getAttribute(userId) != null) {
        		AppUser appUser = (AppUser) session.getAttribute(userId);
        		// closing the connection
        		appUser.getCordaRPCConnection().close();
        		System.out.println("UserLoginController >> Logging out >> invalidating the session for the user..");
        		session.invalidate();
        		customResponse.setOK("success");
        	}
        }
        
        return customResponse;

    }

}
