package com.capgemini.util;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileReader;
import java.util.Iterator;

@Service
public class Util {
	private static JSONArray cordaJsonArray = null;

	@PostConstruct
	public void readFile() {
		// this should come from property file
		String jsonFileCorda = "static/json/docCorda.json";

		ClassLoader classLoader = getClass().getClassLoader();
		File cordaFile = new File(classLoader.getResource(jsonFileCorda).getFile());
		JSONParser parser = new JSONParser();
		try {
			Object corda = parser.parse(new FileReader(cordaFile));
			JSONObject jsonObjectCorda = (JSONObject) corda;
			cordaJsonArray = (JSONArray) jsonObjectCorda.get("updateUsers");
		} catch (Exception e) {
			System.out.println("Exceptiopn " + e.getMessage());
		}
	}
	 public static String getCordaIPAddress(String userId) {

		if (cordaJsonArray != null) {
			Iterator<?> iterator = cordaJsonArray.iterator();
			String userID = "";

			while (iterator.hasNext()) {
				JSONObject object = (JSONObject) iterator.next();
				userID = (String) object.get("userID");
				if (userID.equalsIgnoreCase(userId)) {
					return (String) object.get("blockchainIPAddress");
				}
			}
		}
		return null;
	}

	 public static String getCordaPort(String userId) {

		if (cordaJsonArray != null) {
			Iterator<?> iterator = cordaJsonArray.iterator();
			String userID = "";

			while (iterator.hasNext()) {
				JSONObject object = (JSONObject) iterator.next();
				userID = (String) object.get("userID");
				if (userID.equalsIgnoreCase(userId)) {
					return (String) object.get("port");
				}
			}
		}
		return null;
	}

	public static String getUserRole(String userId) {

		if (cordaJsonArray != null) {
			Iterator<?> iterator = cordaJsonArray.iterator();
			String userID = "";

			while (iterator.hasNext()) {
				JSONObject object = (JSONObject) iterator.next();
				userID = (String) object.get("userID");
				if (userID.equalsIgnoreCase(userId)) {
					return (String) object.get("userRole");
				}
			}
		}
		return null;
	}

	public static Boolean getUserDetails(String userId, String password){
		if (cordaJsonArray != null) {
			Iterator<?> iterator = cordaJsonArray.iterator();
			String userID = "";
			String Password = "";

			while (iterator.hasNext()) {
				JSONObject object = (JSONObject) iterator.next();
				userID = (String) object.get("userID");
				Password = (String) object.get("password");
				if (userID.equalsIgnoreCase(userId) && Password.equals(password)) {
					return true;
				}
			}
		}
		return false;
	}
}