/*
package com.capgemini.model;

public class ParameterData {

    private final int type=1;
   // private ChainCodePojo chaincodeID;
    private CtorMsgData ctorMsg;
    private String secureContext;

    public int getType() {
        return type;
    }




    public CtorMsgData getCtorMsg() {
        return ctorMsg;
    }

    public void setCtorMsg(CtorMsgData ctorMsg) {
        this.ctorMsg = ctorMsg;
    }

    public String getSecureContext() {
        return secureContext;
    }

    public void setSecureContext(String secureContext) {
        this.secureContext = secureContext;
    }

    @Override
    public String toString() {
        return "ParameterData{" +
                "type=" + type +
                ", ctorMsg=" + ctorMsg +
                ", secureContext='" + secureContext + '\'' +
                '}';
    }
}
*/
