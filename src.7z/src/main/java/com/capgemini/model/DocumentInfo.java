package com.capgemini.model;

public class DocumentInfo {
	private String userId;
    private String documentType;
    private String documentId;
    private String docBlob;

    public DocumentInfo(String userId, String documentType, String documentId, String docBlob) {
        this.userId = userId;
        this.documentType = documentType;
        this.documentId = documentId;
        this.docBlob = docBlob;
    }

    public DocumentInfo() {

    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocBlob() {
        return docBlob;
    }

    public void setDocBlob(String docBlob) {
        this.docBlob = docBlob;
    }

    @Override
    public String toString() {
        return "DocumentInfo{" +
                "userId='" + userId + '\'' +
                ", documentType='" + documentType + '\'' +
                ", documentId='" + documentId + '\'' +
                ", docBlob='" + docBlob + '\'' +
                '}';
    }

}
