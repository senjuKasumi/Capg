/*
package com.capgemini.model;

*/
/**
 * Created by dmotwani on 4/28/2017.
 *//*

public class FabricData {

    private String jsonrpc="2.0";
    private String method;
    private ParameterData params;
    private int id;

    public String getJsonrpc() {
        return jsonrpc;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public ParameterData getParams() {
        return params;
    }

    public void setParams(ParameterData params) {
        this.params = params;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "FabricData{" +
                "jsonrpc='" + jsonrpc + '\'' +
                ", method='" + method + '\'' +
                ", params=" + params +
                ", id=" + id +
                '}';
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }
}
*/
