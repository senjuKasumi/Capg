package com.capgemini.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;


public class UserKycInfoDTO
{
	 @JsonProperty
	    private String USER_ID;
	    @JsonProperty
	    private String USER_NAME;
	    @JsonProperty
	    private String KYC_BANK_NAME;
	    @JsonProperty
	    private Date KYC_CREATE_DATE;
	    @JsonProperty
	    private Date KYC_VALID_TILL_DATE;
	    @JsonProperty
	    private String KYC_INFO;

	    @JsonProperty
	    private DocumentInfo userIdentityInfo;
	    @JsonProperty
	    private DocumentInfo userAddressInfo;
	    @JsonProperty
	    private DocumentInfo userOtherDocument;

	    @JsonProperty
	    private String status;
	    @JsonProperty
	    private String userRole;
	    
		@JsonProperty
	    private KycRiskProfile kycRiskProfile;

	    public UserKycInfoDTO() {
	    }

	    public DocumentInfo getUserIdentityInfo() {
	        return userIdentityInfo;
	    }

	    public void setUserIdentityInfo(DocumentInfo userIdentityInfo) {
	        this.userIdentityInfo = userIdentityInfo;
	    }

	    public DocumentInfo getUserAddressInfo() {
	        return userAddressInfo;
	    }

	    public void setUserAddressInfo(DocumentInfo userAddressInfo) {
	        this.userAddressInfo = userAddressInfo;
	    }

	    public String getUSER_ID() {
	        return USER_ID;
	    }

	    public void setUSER_ID(String uSER_ID) {
	        this.USER_ID = uSER_ID;
	    }

	    public String getUSER_NAME() {
	        return USER_NAME;
	    }

	    public void setUSER_NAME(String uSER_NAME) {
	        this.USER_NAME = uSER_NAME;
	    }

	    public String getKYC_BANK_NAME() {
	        return KYC_BANK_NAME;
	    }

	    public void setKYC_BANK_NAME(String kYC_BANK_NAME) {
	        this.KYC_BANK_NAME = kYC_BANK_NAME;
	    }

	    public Date getKYC_CREATE_DATE() {
	        return KYC_CREATE_DATE;
	    }

	    public void setKYC_CREATE_DATE(Date kYC_CREATE_DATE) {
	        this.KYC_CREATE_DATE = kYC_CREATE_DATE;
	    }

	    public Date getKYC_VALID_TILL_DATE() {
	        return KYC_VALID_TILL_DATE;
	    }

	    public void setKYC_VALID_TILL_DATE(Date kYC_VALID_TILL_DATE) {
	        this.KYC_VALID_TILL_DATE = kYC_VALID_TILL_DATE;
	    }

	    public DocumentInfo getUserOtherDocument() {
	        return userOtherDocument;
	    }

	    public void setUserOtherDocument(DocumentInfo userOtherDocument) {
	        this.userOtherDocument = userOtherDocument;
	    }

	    public String getKYC_INFO() {
	        return KYC_INFO;
	    }

	    public void setKYC_INFO(String KYC_INFO) {
	        this.KYC_INFO = KYC_INFO;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }


	    public KycRiskProfile getKycRiskProfile() {
	        return kycRiskProfile;
	    }

	    public void setKycRiskProfile(KycRiskProfile kycRiskProfile) {
	        this.kycRiskProfile = kycRiskProfile;
	    }

	    public String getUserRole() {
			return userRole;
		}

		public void setUserRole(String userRole) {
			this.userRole = userRole;
		}

		@Override
		public String toString() {
			return "UserKycInfo [USER_ID=" + USER_ID + ", USER_NAME=" + USER_NAME + ", KYC_BANK_NAME=" + KYC_BANK_NAME
					+ ", KYC_CREATE_DATE=" + KYC_CREATE_DATE + ", KYC_VALID_TILL_DATE=" + KYC_VALID_TILL_DATE
					+ ", KYC_INFO=" + KYC_INFO + ", userIdentityInfo=" + userIdentityInfo + ", userAddressInfo="
					+ userAddressInfo + ", userOtherDocument=" + userOtherDocument + ", status=" + status
					+ ", userRole=" + userRole + ", kycRiskProfile=" + kycRiskProfile + "]";
		}
		
	
}