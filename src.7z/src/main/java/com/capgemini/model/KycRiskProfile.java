package com.capgemini.model;

public class KycRiskProfile {
	private String userId;    
    private String riskFactor;
    private long averageDailyTransaction;
    private boolean amlCheck;

    public KycRiskProfile() {

    }

    public KycRiskProfile(String userId, String riskFactor, long averageDailyTransaction, boolean amlCheck) {
        this.userId = userId;
        this.riskFactor = riskFactor;
        this.averageDailyTransaction = averageDailyTransaction;
        this.amlCheck = amlCheck;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRiskFactor() {
        return riskFactor;
    }

    public void setRiskFactor(String riskFactor) {
        this.riskFactor = riskFactor;
    }

    public long getAverageDailyTransaction() {
        return averageDailyTransaction;
    }

    public void setAverageDailyTransaction(long averageDailyTransaction) {
        this.averageDailyTransaction = averageDailyTransaction;
    }

    public boolean isAmlCheck() {
        return amlCheck;
    }

    public void setAmlCheck(boolean amlCheck) {
        this.amlCheck = amlCheck;
    }

    @Override
    public String toString() {
        return "KycRiskProfile{" +
                "userId='" + userId + '\'' +
                ", riskFactor='" + riskFactor + '\'' +
                ", averageDailyTransaction=" + averageDailyTransaction +
                ", amlCheck=" + amlCheck +
                '}';
    }

}
