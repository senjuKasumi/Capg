/*
package com.capgemini.model;

public class FabricResponse {
	private Result result;
	private final String jsonrpc="2.0";
	
	private int id;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getJsonrpc() {
		return jsonrpc;
	}

	@Override
	public String toString() {
		return "FabricResponse [result=" + result + ", jsonrpc=" + jsonrpc + ", id=" + id + "]";
	}
	
	
	

}
*/
