package com.capgemini.model;

public class CustomResponse {

    private String OK;
    private String ERROR;
    private String userName;
    private String bankName;
    private String blockChainIpAddress;
    private String serverPort;

    public String getOK() {
        return OK;
    }

    public void setOK(String OK) {
        this.OK = OK;
    }

    public String getERROR() {
        return ERROR;
    }

    public void setERROR(String ERROR) {
        this.ERROR = ERROR;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }


    public String getBlockChainIpAddress() {
        return blockChainIpAddress;
    }

    public void setBlockChainIpAddress(String blockChainIpAddress) {
        this.blockChainIpAddress = blockChainIpAddress;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    @Override
    public String toString() {
        return "CustomResponse{" +
                "OK='" + OK + '\'' +
                ", ERROR='" + ERROR + '\'' +
                ", userName='" + userName + '\'' +
                ", bankName='" + bankName + '\'' +
                ", blockChainIpAddress='" + blockChainIpAddress + '\'' +
                ", serverPort='" + serverPort + '\'' +
                '}';
    }
}
