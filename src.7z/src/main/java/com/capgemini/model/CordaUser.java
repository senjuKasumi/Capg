package com.capgemini.model;

import com.capgemini.mtpdapp.state.MtpState;

public class CordaUser {

    private String userID;
    private String password;
    private String blockchainIPAddress;
    private String bankName;
    private String port;
    private String flag;
    private MtpState state;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBlockchainIPAddress() {
        return blockchainIPAddress;
    }

    public void setBlockchainIPAddress(String blockchainIPAddress) {
        this.blockchainIPAddress = blockchainIPAddress;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "User{" +
                "userID='" + userID + '\'' +
                ", password='" + password + '\'' +
                ", blockchainIPAddress='" + blockchainIPAddress + '\'' +
                ", bankName='" + bankName + '\'' +
                ", port='" + port + '\'' +
                ", flag='" + flag + '\'' +
                '}';
    }
}
