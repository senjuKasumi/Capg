package com.capgemini.model;

import java.util.List;

public class CtorMsgData {
    private String function;
    private List<String> args;

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public List<String> getArgs() {
        return args;
    }

    public void setArgs(List<String> args) {
        this.args = args;
    }


    @Override
    public String toString() {
        return "CtorMsgData{" +
                "function='" + function + '\'' +
                ", args=" + args +
                '}';
    }
}
