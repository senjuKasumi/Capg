package com.capgemini.service;

public interface MtpService {

    /*public Response createTransaction(int value, CordaX500Name partyName);
    Object searchAllTransactions(String flag, String bankName, String userID);

    Object searchUserByUserId(String userId, String flag, String bankName, String consumerUserID);

    Object searchUserByBankName(String bankName, String flag, String userID);

    Object searchKYCCounts(String flag, String bankName, String userID);
*/

}
