package com.capgemini.service;

import com.capgemini.corda.user.AppUser;
import com.capgemini.model.CustomResponse;
import com.capgemini.model.LoginDetails;

public interface UserLoginService {

    CustomResponse validateLogin(LoginDetails loginDetails);
    String checkRole(LoginDetails loginDetails);
	AppUser getAppUser(String userID);
}