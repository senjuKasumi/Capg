package com.capgemini.serviceimpl;

import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import javax.ws.rs.core.Response;

import com.capgemini.corda.core.service.impl.CordaTransactionService;
import com.capgemini.mtpdapp.flow.MtpFlow;
import com.capgemini.mtpdapp.state.MtpState;
import com.capgemini.service.MtpService;
import com.google.common.collect.ImmutableList;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.transactions.SignedTransaction;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;
import com.capgemini.corda.core.exception.CordaVaultQueryException;
import com.capgemini.corda.core.exception.InsufficientRPCPermissionsException;
import com.capgemini.corda.core.exception.InvalidInputException;
import com.capgemini.corda.core.helper.CordaConstant;
import com.capgemini.corda.core.model.BaseAsset;
import com.capgemini.corda.core.service.impl.CordaFileOpService;
import com.capgemini.corda.core.service.impl.CordaNetworkService;
import com.capgemini.corda.core.util.Utility;
import com.capgemini.corda.user.AppUser;
import com.capgemini.model.CustomResponse;
import com.capgemini.model.UserKycInfoDTO;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;
import static javax.ws.rs.core.Response.Status.CREATED;

@Service
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class MtpServiceImpl implements MtpService {

	//private static final Logger logger = Logger.getLogger(KYCFabricService.class);
	private AppUser appUser;
	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}
	private final CordaRPCOps rpcOps;
	private final CordaX500Name myLegalName;
	private final List<String> serviceNames = ImmutableList.of("Notary");

	public MtpServiceImpl(CordaRPCOps rpcOps){
		this.rpcOps = rpcOps;
		this.myLegalName = rpcOps.nodeInfo().getLegalIdentities().get(0).getName();
	}

	@Autowired
	private CordaTransactionService<MtpState> cordaTransactionService;

	@Autowired
	private CordaFileOpService cordaFileOpService;

	@Autowired
	private CordaNetworkService cordaNetworkService;

	private void setAppUserInServices() {
		cordaTransactionService.setAppUser(appUser);
		cordaNetworkService.setAppUser(appUser);
		cordaFileOpService.setAppUser(appUser);
	}

	public Response createTransaction(int value, CordaX500Name partyName){
		final Party otherParty = rpcOps.wellKnownPartyFromX500Name(partyName);
		if (otherParty == null) {
			return Response.status(BAD_REQUEST).entity("Party named " + partyName + "cannot be found.\n").build();
		}
		try{
			SignedTransaction signedTx = rpcOps.startTrackedFlowDynamic(MtpFlow.Initiator.class, value, otherParty).getReturnValue().get();
			final String msg = String.format("Transaction id %s committed to ledger.\n", signedTx.getId());
			return Response.status(CREATED).entity(msg).build();
		}catch (Throwable ex) {
			final String msg = ex.getMessage();
			return Response.status(BAD_REQUEST).entity(msg).build();
		}

	}

	/*Object searchAllTransactions(String flag, String bankName, String userID);

	Object searchUserByUserId(String userId, String flag, String bankName, String consumerUserID);

	Object searchUserByBankName(String bankName, String flag, String userID);

	Object searchKYCCounts(String flag, String bankName, String userID);
*/
	/*
	@Override
	public CustomResponse createKyc(UserKycInfoDTO userKycInfoDTO, String flag, String userID) {

		logger.info("Corda Create KYC");
		
		setAppUserInServices();

		UserKycInfo userKycInfo = new UserKycInfo();

		userKycInfo.setUSER_ID(userKycInfoDTO.getUSER_ID());
		userKycInfo.setUSER_NAME(userKycInfoDTO.getUSER_NAME());
		userKycInfo.setKYC_BANK_NAME(userKycInfoDTO.getKYC_BANK_NAME());
		userKycInfo.setKYC_INFO(userKycInfoDTO.getKYC_INFO());
		userKycInfo.setStatus(userKycInfoDTO.getStatus());
		userKycInfo.setUserAddressInfo(new DocumentInfo(userKycInfoDTO.getUserAddressInfo().getUserId(),
				userKycInfoDTO.getUserAddressInfo().getDocumentType(),
				userKycInfoDTO.getUserAddressInfo().getDocumentId(), userKycInfoDTO.getUserAddressInfo().getDocBlob()));
		logger.info(userKycInfoDTO.getUserAddressInfo().getDocBlob());
		userKycInfo.setUserIdentityInfo(new DocumentInfo(userKycInfoDTO.getUserIdentityInfo().getUserId(),
				userKycInfoDTO.getUserIdentityInfo().getDocumentType(),
				userKycInfoDTO.getUserIdentityInfo().getDocumentId(),
				userKycInfoDTO.getUserIdentityInfo().getDocBlob()));
		logger.info(userKycInfoDTO.getUserIdentityInfo().getDocBlob());
		userKycInfo.setUserOtherDocument(new DocumentInfo(userKycInfoDTO.getUserOtherDocument().getUserId(),
				userKycInfoDTO.getUserOtherDocument().getDocumentType(),
				userKycInfoDTO.getUserOtherDocument().getDocumentId(),
				userKycInfoDTO.getUserOtherDocument().getDocBlob()));
		logger.info(userKycInfoDTO.getUserOtherDocument().getDocBlob());
		userKycInfo.setKycRiskProfile(new KycRiskProfile(userKycInfoDTO.getKycRiskProfile().getUserId(),
				userKycInfoDTO.getKycRiskProfile().getRiskFactor(),
				userKycInfoDTO.getKycRiskProfile().getAverageDailyTransaction(),
				userKycInfoDTO.getKycRiskProfile().isAmlCheck()));

		Calendar currDate = Calendar.getInstance();

		userKycInfo.setKYC_CREATE_DATE(currDate.getTime());

		currDate.add(Calendar.YEAR, 1);
		currDate.add(Calendar.DAY_OF_MONTH, -1);

		userKycInfo.setKYC_VALID_TILL_DATE(currDate.getTime());
		CustomResponse customResponse = new CustomResponse();
		try {

			SecureHash userOtherDocHash = null;
			SecureHash userAddrDocHash = null;
			SecureHash userIdentityDocHash = null;

			Party initiator = cordaNetworkService.getInitiatorParty();
			List<Party> counterParties =
							cordaNetworkService.getPartiesFromX500Names(cordaNetworkService.getPeersOnly().get(CordaConstant.PEERS.getValue()), true);
			
			System.out.println("Length of other Parties: " + counterParties.size());
			System.out.println("Other Parties: " + counterParties);

			userKycInfo.setKYC_VALID_TILL_DATE(Utility.getDateAddingOneYear());
			userKycInfo = setKYCStatus(null, userKycInfo, null, null, null);

			if (userKycInfoDTO.getUserOtherDocument() != null) {
				userOtherDocHash =
						cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserOtherDocument().getDocBlob()));
			}
			if (userKycInfoDTO.getUserAddressInfo() != null && userKycInfoDTO.getUserIdentityInfo() != null) {
				
				userAddrDocHash =
						cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserAddressInfo().getDocBlob())); 
				userIdentityDocHash =
						cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserIdentityInfo().getDocBlob()));
			}

			if (userOtherDocHash != null && userKycInfoDTO.getUserOtherDocument() != null)
				userKycInfo.getUserOtherDocument().setDocBlob(userOtherDocHash.toString());
			if (userAddrDocHash != null)
				userKycInfo.getUserAddressInfo().setDocBlob(userAddrDocHash.toString());
			if (userIdentityDocHash != null)
				userKycInfo.getUserIdentityInfo().setDocBlob(userIdentityDocHash.toString());

			final KycState state = new KycState(userKycInfo, initiator, counterParties, new KycContract(), null,
					userOtherDocHash, userAddrDocHash, userIdentityDocHash);

			System.out.println(">> KYC State is created..");

			try {
				System.out.println(">> KYCCreateFlow is called..");

				Response cordaResponse = cordaTransactionService.createNewAssetWithCustomFlow(KycCreateFlow.Initiator.class, state, counterParties, new BaseAsset() {
					@Override
					public void validate() throws InvalidInputException {}
				}, null, null);
				
				customResponse.setOK((cordaResponse.getStatus() == 200) ? "OK" : cordaResponse.getStatus()+"");
				logger.debug("Corda Response >> CordaTransactionService.createNewAssetWithCustomFlow() >> :" + cordaResponse.getStatus());
			} catch (Exception e) {
				logger.error("Exception Occurred while creating kyc in corda: " + e.getMessage());
				customResponse.setERROR(e.getMessage());
				e.printStackTrace();
			}

		} catch (Exception e) {
			logger.error("Exception Occurred while creating kyc in corda: " + e.getMessage());
			customResponse.setERROR(e.getMessage());

		}
		return customResponse;

	}

	@Override
	public Object searchAllKyc(String flag, String bankName, String userID) {
		return null;
	}

	*//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#searchAllKyc(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//*
	@Override
	public Object searchAllTransactions(String flag, String bankName, String userID) {

		logger.info("Search all Transactions Corda");
		
		setAppUserInServices();

		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		try {			
			List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
			
			for (StateAndRef<KycState> singleRecord : allRecords) {
				KycState poState = (KycState) singleRecord.getState().getData();
				if (poState.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
					userInfoList.add(poState.getUserKycInfo());
				} else if (poState.getUserKycInfo() != null && poState.getUserKycInfo().getStatus() != null
						&& (poState.getUserKycInfo().getStatus()
								.equalsIgnoreCase(KYCStatus.COMPLIANT.value().toString())
								|| poState.getUserKycInfo().getStatus()
										.equalsIgnoreCase(KYCStatus.RISKPROFILECOMPLIANT.value().toString()))) {
					userInfoList.add(poState.getUserKycInfo());
				}
			}

		} catch (Exception e) {
			logger.error("Exception Occurred while returning records: " + e.getMessage());
		}
		return getUserInfoList(userInfoList);

	}

	private Object getUserInfoList(List<UserKycInfo> userInfoList) {
		if (userInfoList.isEmpty()) {
			CustomResponse customResponse = new CustomResponse();
			customResponse.setERROR("error");
			return customResponse;
		} else {
			UserKycInfoDTO[] events = new UserKycInfoDTO[userInfoList.size()];
			int index = 0;
			for (UserKycInfo userKycInfo : userInfoList) {
				UserKycInfoDTO userKycInfoDTO = new UserKycInfoDTO();

				userKycInfoDTO.setUSER_ID(userKycInfo.getUSER_ID());
				userKycInfoDTO.setUSER_NAME(userKycInfo.getUSER_NAME());
				userKycInfoDTO.setKYC_BANK_NAME(userKycInfo.getKYC_BANK_NAME());
				userKycInfoDTO.setKYC_INFO(userKycInfo.getKYC_INFO());
				userKycInfoDTO.setStatus(userKycInfo.getStatus());
				userKycInfoDTO.setKYC_CREATE_DATE(userKycInfo.getKYC_CREATE_DATE());
				userKycInfoDTO.setKYC_VALID_TILL_DATE(userKycInfo.getKYC_VALID_TILL_DATE());
				
				userKycInfoDTO.setUserAddressInfo(new com.capgemini.model.DocumentInfo(userKycInfo.getUserAddressInfo().getUserId(),
						userKycInfo.getUserAddressInfo().getDocumentType(),
						userKycInfo.getUserAddressInfo().getDocumentId(),
						userKycInfo.getUserAddressInfo().getDocBlob()));
				userKycInfoDTO.setUserIdentityInfo(new com.capgemini.model.DocumentInfo(userKycInfo.getUserIdentityInfo().getUserId(),
						userKycInfo.getUserIdentityInfo().getDocumentType(),
						userKycInfo.getUserIdentityInfo().getDocumentId(),
						userKycInfo.getUserIdentityInfo().getDocBlob()));
				userKycInfoDTO.setUserOtherDocument(new com.capgemini.model.DocumentInfo(userKycInfo.getUserOtherDocument().getUserId(),
						userKycInfo.getUserOtherDocument().getDocumentType(),
						userKycInfo.getUserOtherDocument().getDocumentId(),
						userKycInfo.getUserOtherDocument().getDocBlob()));
				userKycInfoDTO.setKycRiskProfile(new com.capgemini.model.KycRiskProfile(userKycInfo.getKycRiskProfile().getUserId(),
						userKycInfo.getKycRiskProfile().getRiskFactor(),
						userKycInfo.getKycRiskProfile().getAverageDailyTransaction(),
						userKycInfo.getKycRiskProfile().getAmlCheck()));
				 

				events[index] = userKycInfoDTO;
				index++;
			}
			logger.debug("All records returned successfully: " + events);
			return events;
		}
	}

	*//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#searchUserByUserId(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 *//*
	@Override
	public Object searchUserByUserId(String userID, String flag, String bankName, String consumerUserID) {

		logger.info("Corda search kyc by userId");
		
		setAppUserInServices();

		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		try {

			List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(MtpState.class);
			
			for (StateAndRef<MtpState> singleRecord : allRecords) {
				KycState poState = (KycState) singleRecord.getState().getData();

				if (poState.getUserKycInfo().getUSER_ID().equals(consumerUserID)
						&& poState.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
					userInfoList.add(poState.getUserKycInfo());
				} else if (poState.getUserKycInfo() != null && poState.getUserKycInfo().getStatus() != null
						&& poState.getUserKycInfo().getUSER_ID().equals(consumerUserID)
						&& (poState.getUserKycInfo().getStatus()
								.equalsIgnoreCase(KYCStatus.COMPLIANT.value().toString())
								|| poState.getUserKycInfo().getStatus()
										.equalsIgnoreCase(KYCStatus.RISKPROFILECOMPLIANT.value().toString()))) {
					userInfoList.add(poState.getUserKycInfo());
				}
			}

		} catch (Exception e) {
			logger.error("Exception Occurred while retrieving the records: " + e.getMessage());
		}
		return getUserInfoList(userInfoList);

	}

	*//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#searchUserByBankName(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//*
	@Override
	public Object searchUserByBankName(String bankName, String flag, String userID) {

		logger.info("Corda Search Kyc by bank Name");
		
		setAppUserInServices();

		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		try {
			
			List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);

			if (allRecords != null) {
				for (StateAndRef<KycState> singleRecord : allRecords) {
					KycState state = (KycState) singleRecord.getState().getData();

					if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
						userInfoList.add(state.getUserKycInfo());
					}
				}
			}

		} catch (Exception e) {
			logger.error("Exception Occurred while retrieving the records: " + e.getMessage());
		}
		return getUserInfoList(userInfoList);
	}

	private UserKycInfo calculateValidTillDate(UserKycInfo userKycInfo) {
		if (null != userKycInfo.getKycRiskProfile() && userKycInfo.getKycRiskProfile().getRiskFactor() != null) {
			String riskFactor = userKycInfo.getKycRiskProfile().getRiskFactor();
			Calendar currentDateCal = Calendar.getInstance();
			currentDateCal.set(Calendar.HOUR_OF_DAY, 0);
			currentDateCal.set(Calendar.MINUTE, 0);
			currentDateCal.set(Calendar.SECOND, 0);
			currentDateCal.set(Calendar.MILLISECOND, 0);
			if (riskFactor.equalsIgnoreCase("HIGH")) {

				currentDateCal.add(Calendar.MONTH, 6);
				currentDateCal.add(Calendar.DAY_OF_MONTH, -1);
				Date futureDate = currentDateCal.getTime();
				userKycInfo.setKYC_VALID_TILL_DATE(futureDate);
			} else if (riskFactor.equalsIgnoreCase("MEDIUM")) {
				currentDateCal.add(Calendar.YEAR, 1);
				currentDateCal.add(Calendar.DAY_OF_MONTH, -1);
				Date futureDate = currentDateCal.getTime();
				userKycInfo.setKYC_VALID_TILL_DATE(futureDate);
			} else if (riskFactor.equalsIgnoreCase("LOW")) {
				currentDateCal.add(Calendar.YEAR, 2);
				currentDateCal.add(Calendar.DAY_OF_MONTH, -1);
				Date futureDate = currentDateCal.getTime();
				userKycInfo.setKYC_VALID_TILL_DATE(futureDate);
			}
		} else
			//userKycInfo.setKYC_VALID_TILL_DATE(calculateValidTillDateForCreate());
			userKycInfo.setKYC_VALID_TILL_DATE(Utility.getDateAddingOneYear());

		return userKycInfo;
	}

	*//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#updateDocument(com.capgemini.model.
	 * UserKycInfoDTO, java.lang.String, java.lang.String)
	 *//*
	@Override
	public CustomResponse updateDocument(UserKycInfoDTO userKycInfoDTO, String flag, String userID) {

		setAppUserInServices();

		Calendar currDate = Calendar.getInstance();
		currDate.add(Calendar.YEAR, 1);

		UserKycInfo userKycInfo = new UserKycInfo();
		userKycInfo.setUSER_ID(userKycInfoDTO.getUSER_ID());
		userKycInfo.setUSER_NAME(userKycInfoDTO.getUSER_NAME());
		userKycInfo.setKYC_BANK_NAME(userKycInfoDTO.getKYC_BANK_NAME());
		userKycInfo.setKYC_INFO(userKycInfoDTO.getKYC_INFO());
		userKycInfo.setStatus(userKycInfoDTO.getStatus());
		userKycInfo.setKYC_CREATE_DATE(userKycInfoDTO.getKYC_CREATE_DATE());
		//userKycInfo.setKYC_VALID_TILL_DATE(userKycInfoDTO.getKYC_VALID_TILL_DATE());
		
		userKycInfo.setKYC_VALID_TILL_DATE(currDate.getTime());
		userKycInfo.setStatus(userKycInfoDTO.getStatus());
		userKycInfo.setUserAddressInfo(new DocumentInfo(userKycInfoDTO.getUserAddressInfo().getUserId(),
				userKycInfoDTO.getUserAddressInfo().getDocumentType(),
				userKycInfoDTO.getUserAddressInfo().getDocumentId(), userKycInfoDTO.getUserAddressInfo().getDocBlob()));
		userKycInfo.setUserIdentityInfo(new DocumentInfo(userKycInfoDTO.getUserIdentityInfo().getUserId(),
				userKycInfoDTO.getUserIdentityInfo().getDocumentType(),
				userKycInfoDTO.getUserIdentityInfo().getDocumentId(),
				userKycInfoDTO.getUserIdentityInfo().getDocBlob()));
		userKycInfo.setUserOtherDocument(new DocumentInfo(userKycInfoDTO.getUserOtherDocument().getUserId(),
				userKycInfoDTO.getUserOtherDocument().getDocumentType(),
				userKycInfoDTO.getUserOtherDocument().getDocumentId(),
				userKycInfoDTO.getUserOtherDocument().getDocBlob()));
		userKycInfo.setKycRiskProfile(new KycRiskProfile(userKycInfoDTO.getKycRiskProfile().getUserId(),
				userKycInfoDTO.getKycRiskProfile().getRiskFactor(),
				userKycInfoDTO.getKycRiskProfile().getAverageDailyTransaction(),
				userKycInfoDTO.getKycRiskProfile().isAmlCheck()));

		CustomResponse customResponse = new CustomResponse();
		try {

			List<Party> counterParties =
							cordaNetworkService.getPartiesFromX500Names(cordaNetworkService.getPeersOnly().get(CordaConstant.PEERS.getValue()), true);
			System.out.println("MtpServiceImpl >> counter parties obtained..");
			SecureHash userOtherDocHash = null;
			SecureHash userAddrDocHash = null;
			SecureHash userIdentityDocHash = null;
			KycState newKycState = null;
			StateAndRef<KycState> oldStateAndRef = null;
			KycState oldKycStateObj = null;
						
			List<StateAndRef<KycState>> kycStates = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
			System.out.println("MtpServiceImpl >> old states and refs obtained..");
			try {
				if (kycStates != null && kycStates.size() != 0) {
					for (StateAndRef<KycState> singleRecord : kycStates) {
						oldKycStateObj = (KycState) singleRecord.getState().getData();
						if (oldKycStateObj != null) {
							if (oldKycStateObj.getUserKycInfo().getUSER_ID().equals(userKycInfo.getUSER_ID())) {
								oldStateAndRef = singleRecord;
								break;
							}
						}
					}
				}
				
				if (userKycInfoDTO != null && userKycInfoDTO.getUserRole() != null
						&& userKycInfoDTO.getUserRole().equalsIgnoreCase("Bank")) {
					userOtherDocHash = oldKycStateObj.getOtherDocHash();
					userAddrDocHash = oldKycStateObj.getAddrDocHash();
					userIdentityDocHash = oldKycStateObj.getIdentityDocHash();
					
				} else { // if the user is other than bank then check/retrieve for the attachments in the
							// supplied userKycInfo
					if (userKycInfoDTO.getUserOtherDocument() != null) {
						//userOtherDocHash = uploadAttachment(userKycInfo.getUserOtherDocument().getDocBlob(), proxy);
						System.out.println("MtpServiceImpl >> userKycInfoDTO : checking whether the dto has other doc..");
						userOtherDocHash =  cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserOtherDocument().getDocBlob()));
						
					}
					//userAddrDocHash = uploadAttachment(userKycInfo.getUserAddressInfo().getDocBlob(), proxy);
					userAddrDocHash =  cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserAddressInfo().getDocBlob()));
					//userIdentityDocHash = uploadAttachment(userKycInfo.getUserIdentityInfo().getDocBlob(), proxy);
					userIdentityDocHash =  cordaFileOpService.uploadAttachment(Base64.getDecoder().decode(userKycInfoDTO.getUserIdentityInfo().getDocBlob()));
				}
				
				// This code snippet is to make sure the 3 kind of attachments available in
				// every transaction and every state.
				if (userOtherDocHash != null && userKycInfo.getUserOtherDocument() != null)
					System.out.println("MtpServiceImpl >> userOtherDocHash : setting userOtherDocHash..");
					userKycInfo.getUserOtherDocument().setDocBlob(userOtherDocHash.toString());
				if (userAddrDocHash != null)
					userKycInfo.getUserAddressInfo().setDocBlob(userAddrDocHash.toString());
				if (userIdentityDocHash != null)
					userKycInfo.getUserIdentityInfo().setDocBlob(userIdentityDocHash.toString());
								
				if (oldKycStateObj != null) {
					
					if (oldKycStateObj.getUserKycInfo().getKYC_BANK_NAME()
							.equalsIgnoreCase(userKycInfo.getKYC_BANK_NAME())) {
						
						userKycInfo = setKYCStatus(oldKycStateObj, userKycInfo, userOtherDocHash, userAddrDocHash,
								userIdentityDocHash);
						
						if (null == oldKycStateObj.getUserKycInfo().getKycRiskProfile()
								|| (null != oldKycStateObj.getUserKycInfo().getKycRiskProfile()
										&& null != userKycInfo.getKycRiskProfile()
										&& oldKycStateObj.getUserKycInfo().getKycRiskProfile().getRiskFactor() != null
										&& !oldKycStateObj.getUserKycInfo().getKycRiskProfile().getRiskFactor()
												.equalsIgnoreCase(userKycInfo.getKycRiskProfile().getRiskFactor()))) {
							
							userKycInfo = calculateValidTillDate(userKycInfo);
						}
						
					} else {
						userKycInfo.setKycRiskProfile(oldKycStateObj.getUserKycInfo().getKycRiskProfile());
						throw new IllegalArgumentException(
								"Bank Can Update Risk Profile Information Of There Customers Only.");
					}
					
					newKycState = oldKycStateObj.copy(userKycInfo, userOtherDocHash, userAddrDocHash,
							userIdentityDocHash);
				}
				System.out.println("MtpServiceImpl >> invoking the amend flow..");
				Response cordaResponse = cordaTransactionService.updateLedgerTransaction(KycAmendFlow.InitiatorAmend.class, newKycState, oldStateAndRef, counterParties);
				
				customResponse.setOK((cordaResponse.getStatus() == 200) ? "OK" : cordaResponse.getStatus()+"");
				logger.debug("Corda Response >> CordaTransactionService.createNewAssetWithCustomFlow() >> :" + cordaResponse.getStatus());
				
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
				customResponse.setERROR(ex.getMessage());
			}
			

		} catch (Exception e) {
			logger.error("Exception Occurred while creating kyc in corda: " + e.getMessage());
			customResponse.setERROR(e.getMessage());
		}
		return customResponse;
	}

	public int getTransactionCountByBankName(String bankName) throws CordaVaultQueryException, InsufficientRPCPermissionsException {
		
		List<StateAndRef<MtpState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(MtpState.class);
		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		
		for (StateAndRef<KycState> singleRecord : allRecords) {
			KycState state = (KycState) singleRecord.getState().getData();
			
			if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
				userInfoList.add(state.getUserKycInfo());
			}
		}
		return userInfoList.size();
	}

	*//*public List<UserKycInfo> getKycDetailsByExpiryMonth(String bankName) throws CordaVaultQueryException, InsufficientRPCPermissionsException {

		List<UserKycInfo> finalUserInfoList = new ArrayList<>();
		
		List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		
		for (StateAndRef<KycState> singleRecord : allRecords) {
			KycState state = (KycState) singleRecord.getState().getData();
			
			if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
				userInfoList.add(state.getUserKycInfo());
			}
		}
		
		if (userInfoList != null && userInfoList.size() > 0) {
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day = 1;
			cal.set(year, month, day, 0, 0, 0);
			cal.set(Calendar.MILLISECOND, 0);
			int numOfDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			//
			Date startDate = cal.getTime();
			cal.add(Calendar.DAY_OF_MONTH, numOfDaysInMonth - 1);
			Date endDate = cal.getTime();
			//
			for (UserKycInfo kycObj : userInfoList) {
				if (kycObj != null) {
					Calendar calendar1 = Calendar.getInstance();
					calendar1.setTime(kycObj.getKYC_VALID_TILL_DATE());
					calendar1.set(Calendar.HOUR, 0);
					calendar1.set(Calendar.MINUTE, 0);
					calendar1.set(Calendar.SECOND, 0);
					calendar1.set(Calendar.MILLISECOND, 0);
					//
					Date kycDocValidTillDate = null;
					kycDocValidTillDate = calendar1.getTime();
					//
					if ((kycDocValidTillDate.after(startDate) && (kycDocValidTillDate.before(endDate)))
							|| (kycDocValidTillDate.compareTo(startDate) == 0
									|| kycDocValidTillDate.compareTo(endDate) == 0)) {
						// System.out.println("Date is between expiry Month...");
						finalUserInfoList.add(kycObj);
					} else {
						// System.out.println("Date Is not between expiry Month...");
					}
				}
			}
		}
		return finalUserInfoList;
	}
*//*
	*//*public List<UserKycInfo> getKycByCreatedMonth(String bankName) throws CordaVaultQueryException, InsufficientRPCPermissionsException {
		
		List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
		List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
		
		List<UserKycInfo> finalUserInfoList = new ArrayList<>();
		for (StateAndRef<KycState> singleRecord : allRecords) {
			KycState state = (KycState) singleRecord.getState().getData();
			if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
				userInfoList.add(state.getUserKycInfo());
			}
		}

		if (userInfoList != null && userInfoList.size() > 0) {
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day = 1;
			cal.set(year, month, day, 0, 0, 0);
			cal.set(Calendar.MILLISECOND, 0);
			int numOfDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			
			Date startDate = cal.getTime();
			cal.add(Calendar.DAY_OF_MONTH, numOfDaysInMonth - 1);
			Date endDate = cal.getTime();
			
			for (UserKycInfo kycObj : userInfoList) {
				if (kycObj != null) {
					
					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(kycObj.getKYC_CREATE_DATE());
					calendar2.set(Calendar.HOUR, 0);
					calendar2.set(Calendar.MINUTE, 0);
					calendar2.set(Calendar.SECOND, 0);
					calendar2.set(Calendar.MILLISECOND, 0);
					
					Date kycCreateDate = null;
					kycCreateDate = calendar2.getTime();

					if ((kycCreateDate.after(startDate) && (kycCreateDate.before(endDate)))
							|| (kycCreateDate.compareTo(startDate) == 0 || kycCreateDate.compareTo(endDate) == 0)) {
						// System.out.println("Date is between Current Month...");
						finalUserInfoList.add(kycObj);
					} else {
						// System.out.println("Date is not between Current Month...");
					}
				}
			}
		}
		return finalUserInfoList;
	}
*//*
	*//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#searchKYCCounts(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//*
	@Override
	public Object searchKYCCounts(String flag, String bankName, String userID) {

		logger.info("Corda Searh KYC Counts");

		setAppUserInServices();
		
		Map<String, Integer> countMap = new HashMap<>();
		try {

			countMap.put("AllContracts", getKycCountByBankName(bankName));
			
			List<UserKycInfo> userInfoList2 = getKycDetailsByExpiryMonth(bankName);
			if (userInfoList2 != null) {
				countMap.put("ExpiringContracts", userInfoList2.size());
			} else {
				countMap.put("ExpiringContracts", 0);
			}
			
			List<UserKycInfo> userInfoList3 = getKycByCreatedMonth(bankName);
			if (userInfoList3 != null) {
				countMap.put("CreatedContracts", userInfoList3.size());
			} else {
				countMap.put("CreatedContracts", 0);
			}

		} catch (Exception e) {
			logger.error("Exception Occurred while getting kyc count: " + e.getMessage());

		}
		return countMap;

	}

	@Override
	public Object searchKYCByCreatedMonth(String flag, String bankName, String userID) {
		return null;
	}

	@Override
	public Object searchKYCByExpiringMonth(String flag, String bankName, String userID) {
		return null;
	}

	@Override
	public byte[] getKYCAttachedDoc(String flag, String userId, String docHash) {
		return new byte[0];
	}

	*//*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.service.MtpService#searchKYCByCreatedMonth(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//*
	*//*@Override
	public Object searchKYCByCreatedMonth(String flag, String bankName, String userID) {

		logger.info("corda Search Kyc by created month");
		
		setAppUserInServices();

		List<UserKycInfo> finalUserInfoList = new ArrayList<>();
		try {
			
			List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
			List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();

			for (StateAndRef<KycState> singleRecord : allRecords) {
				KycState state = (KycState) singleRecord.getState().getData();

				if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
					userInfoList.add(state.getUserKycInfo());
				}
			}

			if (userInfoList != null && userInfoList.size() > 0) {
				Calendar cal = Calendar.getInstance();
				int year = cal.get(Calendar.YEAR);
				int month = cal.get(Calendar.MONTH);
				int day = 1;
				cal.set(year, month, day, 0, 0, 0);
				cal.set(Calendar.MILLISECOND, 0);
				int numOfDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

				Date startDate = cal.getTime();
				cal.add(Calendar.DAY_OF_MONTH, numOfDaysInMonth - 1);
				Date endDate = cal.getTime();

				for (UserKycInfo kycObj : userInfoList) {
					if (kycObj != null) {

						Calendar calendar2 = Calendar.getInstance();
						calendar2.setTime(kycObj.getKYC_CREATE_DATE());
						calendar2.set(Calendar.HOUR, 0);
						calendar2.set(Calendar.MINUTE, 0);
						calendar2.set(Calendar.SECOND, 0);
						calendar2.set(Calendar.MILLISECOND, 0);

						Date kycCreateDate = null;
						kycCreateDate = calendar2.getTime();

						if ((kycCreateDate.after(startDate) && (kycCreateDate.before(endDate)))
								|| (kycCreateDate.compareTo(startDate) == 0 || kycCreateDate.compareTo(endDate) == 0)) {
							// System.out.println("Date is between Current Month...");
							finalUserInfoList.add(kycObj);
						} else {
							// System.out.println("Date is not between Current Month...");
						}
					}
				}
			}

		} catch (Exception e) {
			logger.error("Exception occurred: " + e.getMessage());
		}

		return getUserInfoList(finalUserInfoList);

	}

	*//**//*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.service.MtpService#searchKYCByExpiringMonth(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//**//*
	@Override
	public Object searchKYCByExpiringMonth(String flag, String bankName, String userID) {

		logger.info("Corda Search Kyc by expiring month");
		
		setAppUserInServices();

		List<UserKycInfo> finalUserInfoList = new ArrayList<>();
		try {
			
			List<StateAndRef<KycState>> allRecords = cordaTransactionService.getUnConsumedStatesAndRef(KycState.class);
			List<UserKycInfo> userInfoList = new ArrayList<UserKycInfo>();
			
			for (StateAndRef<KycState> singleRecord : allRecords) {
				KycState state = (KycState) singleRecord.getState().getData();
				
				if (state.getUserKycInfo().getKYC_BANK_NAME().equalsIgnoreCase(bankName)) {
					userInfoList.add(state.getUserKycInfo());
				}
			}
			
			if (userInfoList != null && userInfoList.size() > 0) {
				Calendar cal = Calendar.getInstance();
				int year = cal.get(Calendar.YEAR);
				int month = cal.get(Calendar.MONTH);
				int day = 1;
				cal.set(year, month, day, 0, 0, 0);
				cal.set(Calendar.MILLISECOND, 0);
				int numOfDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
				
				Date startDate = cal.getTime();
				cal.add(Calendar.DAY_OF_MONTH, numOfDaysInMonth - 1);
				Date endDate = cal.getTime();
				
				for (UserKycInfo kycObj : userInfoList) {
					if (kycObj != null) {
						Calendar calendar1 = Calendar.getInstance();
						calendar1.setTime(kycObj.getKYC_VALID_TILL_DATE());
						calendar1.set(Calendar.HOUR, 0);
						calendar1.set(Calendar.MINUTE, 0);
						calendar1.set(Calendar.SECOND, 0);
						calendar1.set(Calendar.MILLISECOND, 0);
						
						Date kycDocValidTillDate = null;
						kycDocValidTillDate = calendar1.getTime();
						
						if ((kycDocValidTillDate.after(startDate) && (kycDocValidTillDate.before(endDate)))
								|| (kycDocValidTillDate.compareTo(startDate) == 0
										|| kycDocValidTillDate.compareTo(endDate) == 0)) {
							// System.out.println("Date is between expiry Month...");
							finalUserInfoList.add(kycObj);
						} else {
							// System.out.println("Date Is not between expiry Month...");
						}
					}
				}
			}

		} catch (Exception e) {
			logger.error("Exception Occurred :" + e.getMessage());
		}
		return getUserInfoList(finalUserInfoList);

	}

	*//**//*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.service.MtpService#getKYCAttachedDoc(java.lang.String,
	 * java.lang.String, java.lang.String)
	 *//**//*
	@Override
	public byte[] getKYCAttachedDoc(String flag, String userId, String docHash) {

		logger.info("MtpServiceImpl >> Corda Download KYC attachment");

		setAppUserInServices();

		byte[] documentBytes = null;

		try {

			documentBytes = cordaFileOpService.downloadAttachment(docHash);
			
			System.out.println("MtpServiceImpl >> Document hash is returned successfully!");
			logger.debug("Document hash is returned successfully!");

		} catch (Exception e) {
			logger.error("Exception Occurred while getting kyc attachment : " + e.getMessage());

		}

		return documentBytes;
	}*//*
*/
}
