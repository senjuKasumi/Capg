package com.capgemini.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.capgemini.corda.user.AppUser;
import com.capgemini.corda.user.mngmt.UserManagementImpl;
import com.capgemini.model.CustomResponse;
import com.capgemini.model.LoginDetails;
import com.capgemini.service.UserLoginService;
import com.capgemini.util.Util;

//import static com.capgemini.util.Util.cordaJsonArray;

@Service
public class UserLoginServiceImpl implements UserLoginService {

	@Autowired
	private RestTemplate restTemplate;

	private static final String PASSWORD = "1234";

	@Override
	public CustomResponse validateLogin(LoginDetails loginDetails) {

        CustomResponse customResponse = new CustomResponse();
        Boolean valid = Util.getUserDetails(loginDetails.getUserId(), loginDetails.getPassword());
        if (valid)
            customResponse.setOK("User " + loginDetails.getUserId() + " is logged in.");
        else
            customResponse.setERROR("UserId or password is incorrect");
        return customResponse;
    }

    public String checkRole(LoginDetails loginDetails)
    {
        String role = Util.getUserRole(loginDetails.getUserId());
        return role;
    }

    @Override
	public AppUser getAppUser(String userID) {
		
		String nodeIPAddress = Util.getCordaIPAddress(userID);
		String nodeUserRPCPort = Util.getCordaPort(userID);
		
		UserManagementImpl userManagementImpl = new UserManagementImpl();
		
		return userManagementImpl.getDeveloperAppUser(userID, PASSWORD, nodeIPAddress, nodeUserRPCPort);
	}
	 

}