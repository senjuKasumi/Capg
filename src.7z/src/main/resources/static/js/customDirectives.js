App.directive('publicHeader',function(){
	return{
		templateUrl:"partials/publicHeader.html"
	}
});


App.directive('footerDirective', function(){
	return{
		templateUrl:"partials/footer.html"
	}
});