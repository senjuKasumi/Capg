App.factory('mainService',function($http, $q){
	
	return{
	    setAppStatus : 'h',
	    
		getDetails: function(url){
			console.log("url in getDetails",url);
			var deffered = $q.defer();
			//var url = url + '/registrar';
			$http.post(url).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});
			return deffered.promise;
		},
	
		getDetailsForCorda: function(url){
			var deffered = $q.defer();
			//var url = url + '/registrar';
			$http.get(url).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});

			return deffered.promise;
		},
		
		getTempDetails: function(details, url){
			var deffered = $q.defer();
			$http.post(url, details).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});

			return deffered.promise;
		},
		
		getTempLogin: function(url){
			var deffered = $q.defer();
			//var url = url + '/registrar';
			$http.get(url).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});

			return deffered.promise;
		},

		
		getLogin: function(details, url){
			console.log("Details",details);
			var deffered = $q.defer();
			//var url = url + '/registrar';
			$http.post(url, details).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});
			return deffered.promise;
		},
		
		// changes made by Ahmed
		setLogout: function(url){
			console.log("logout url >> ",url);
			var deffered = $q.defer();
			
			$http.get(url).
			success(function(data, status, headers, config){
				deffered.resolve(data);
			}).
			error(function(data, status, headers, config){
				deffered.reject(data);
			});
			
			return deffered.promise;
		},
		// end of changes made by Ahmed
		
		getBase64File: function(file,category) {
	        // Creates a Deferred object
	        var deferred = $q.defer();
	        var string;
			var base64file;
	        if(file &&(file.type=='application/x-zip-compressed' || file.name.trim().endsWith(".zip")|| file.name.trim().endsWith(".ZIP"))){
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function () {
					base64file =reader.result;
					string = base64file.substring(41);
					
					//Resolve the promise at the end of the file if said file is there
					deferred.resolve(string);
					
				}
				reader.onerror = function (error) {	};
			}
	        else if(category=="other" && file==null){
	        	deferred.resolve(null);
	        	//return null if other doc is null
			}
	        else {
                deferred.reject("Please select ZIP document only");
            } 
	        // The promise of the deferred task
	        return deferred.promise;
	    }
	  
	}
	
	
});

App.factory('sessionService', function(){
    return{
           set:function(key,value){
                  return sessionStorage.setItem(key,JSON.stringify(value));
           },
           get:function(key){
                  return JSON.parse(sessionStorage.getItem(key));
           },
           destroy:function(key){
                  //$http.post('data/destroy_session.php');
                  return sessionStorage.removeItem(key);
           }
    };
});
