var App = angular.module('App', ['ui.router',  'ngAnimate', 'ui.bootstrap',  'ui.tab.scroll', 'ngStorage', 'ui.bootstrap','ngCookies']);

App.value('cordaStatus',false);

console.log('App called');

App.config(function($stateProvider, $urlRouterProvider,  $httpProvider){
	
$urlRouterProvider.otherwise("/default");	

cordaStatus = false;

$stateProvider
		.state('default', {
			url: "/default",
			templateUrl: "partials/default.html",
		})
		.state('loginCorda', {
			url: "/corda/main",
			templateUrl: "partials/login.html",
			controller:'loginCtrlCorda'
		})
		.state('loginFabric', {
			url: "/hyperLedger/main",
			templateUrl: "partials/login.html",
			controller:'loginCtrl'
       })
       .state('login', {
	        url: "/hyperLedger/main",
	        templateUrl: "partials/login.html",
	        controller:'loginCtrl',
	   })
	   .state('index', {
	        url: "/index",
	        templateUrl: "partials/index.html",
	        controller : "mainCtrl"
	   }).state('success', {
			url: "/success",
			templateUrl: "partials/success.html",
			controller : "successCtrl",
			params : {
	        	successMsg:null
			}
	   }).state('dashCorda',{
			url:"/c/dashboard",
			templateUrl:"partials/dashboardCorda.html",
			controller:"dashboardCtrl",
			params : {
	        	corda:cordaStatus
			}
		}).state('dashboard',{
			url:"/dashboard",
			templateUrl:"partials/dashboard.html",
			controller:"dashboardCtrl",
			params : {
	        	corda:cordaStatus
			}
		}).state('dashConsumer',{
			url:"/consumer",
			templateUrl:"partials/dashConsumer.html",
			controller:"dashConsumerCtrl",
			params : {
	        	corda:cordaStatus
			}
		
		}).state('add',{
			url:"/add",
			templateUrl:"partials/addKYC.html",
			controller:"addKycCtrl",
			params : {
	        	corda:cordaStatus
			}
		}).state('update',{
			url:"/update",
			templateUrl:"partials/updateKYC.html",
			controller:"updateoperationCtrl",	
			params:{
				queryObj:null,
				corda:cordaStatus
			}
		
		}).state('operationQuery', {
			url:"/operationQuery",
			templateUrl:"partials/operationQuery.html",
			controller:"operationQueryCtrl",
			params:{
				queryObj:null,
				listRoute:null,
				corda:cordaStatus,
				updateQueryObj:null
			}
		});

});

App.factory('httpInterceptor', function ($q, $rootScope, $log) {

    var numLoadings = 0;

    return {
        request: function (config) {

            numLoadings++;

            // Show loader
            $rootScope.$broadcast("loader_show");
            return config || $q.when(config);

        },
        response: function (response) {

            if ((--numLoadings) === 0) {
                // Hide loader
                $rootScope.$broadcast("loader_hide");
            }

            return response || $q.when(response);

        },
        responseError: function (response) {

            if (!(--numLoadings)) {
                // Hide loader
                $rootScope.$broadcast("loader_hide");
            }

            return $q.reject(response);
        }
    };
});

App.config(function ($httpProvider) {
    $httpProvider.interceptors.push('httpInterceptor');
	$httpProvider.interceptors.push(function ($q, $location, $injector) {
	    return {
		'responseError': function (rejection) {
			if(rejection.status == 400){
				return $q.reject(rejection);
			}else {
				
			}
			
			
		}
	    };
	}); 
});

App.directive("loader", function ($rootScope, $timeout) {
	return function ($scope, element, attrs) {
        $scope.$on("loader_show", function () {
            return element.show();
        });
        return $scope.$on("loader_hide", function () {
            return element.hide();
        });
    };
});

