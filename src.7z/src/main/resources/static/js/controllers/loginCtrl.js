App.controller('loginCtrl',['$scope', '$location','$rootScope', '$state', '$timeout', 'mainService','sessionService','$localStorage', '$http', 
                                 function($scope , $location, $rootScope, $state, $timeout, mainService,sessionService, $localStorage, $http){
	$scope.LoggedUser={};
	mainService.setAppStatus = 'h';
	
	$scope.flag = mainService.setAppStatus;

	$scope.login = function(userid,pwd){
		console.log('loginFabric called');
		
		$scope.loginUrl='json/doc.json';
		mainService.getTempLogin($scope.loginUrl).then(function(result){
			if(result.Failure){
				$scope.error = result;
				return false;
			}
			else if (result){
				for(var i=0;i<result.updateUsers.length;i++){
					if(result.updateUsers[i].userID == userid && result.updateUsers[i].password==pwd){
						$scope.error="";
						$scope.LoggedUser={
							//ipAddress:result.updateUsers[i].blockchainIPAddress,
							serverPort:result.updateUsers[i].port,
							ipAddress:$location.host(),
							port:result.servicePort,
							userid:result.updateUsers[i].userID,
							bankName:result.updateUsers[i].bankName,
							password:result.updateUsers[i].password,
							userRole:result.updateUsers[i].userRole,
						//	blockChainIp:result.updateUsers[i].blockchainIPAddress
							blockChainIp:$location.host()
						}
						localStorage.setItem('loggedUser',JSON.stringify($scope.LoggedUser));
						$rootScope.userRole = result.userRole;
						logon()
						
						var LoggedUser={
							ipAddress:$location.host(),
							port:$scope.loggedUser.servicePort,
							userid:$scope.loggedUser.userid,
							userName:$scope.loggedUser.userName,
							password:$scope.loggedUser.password,
							userRole:$scope.loggedUser.userRole,
							bankName:$scope.loggedUser.bankName,
							blockchainIPAddress:$scope.loggedUser.blockchainIPAddress,
							blockchainPort:$scope.loggedUser.blockchainPort
						}
						sessionService.set('loggedUser', LoggedUser);
					
						/*var loggedUserObj = sessionService.get('loggedUser');
						console.log("bankName1",bankName1);*/
				
					}else{
						$timeout(function() {
							$scope.error="Userid/ password is wrong!!"
					    }, 1000);
					}
				}
			}	
		}, function(error){
			$scope.error = error;
		});
				
		function logon(){	
			$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
							
			$scope.ipAddress = $scope.loggedUser.ipAddress;	
			$scope.port = $scope.loggedUser.port;
			$scope.blockchainIPAddress = $scope.loggedUser.blockchainIPAddress;
			$scope.blockchainPort = $scope.loggedUser.blockchainPort;

			$scope.error = "";
		
			$scope.url = 'http://'+ $scope.ipAddress + ':' + $scope.port;
			
			
			$scope.fullUrl = $scope.url + '/kycapp/api/login/check';
			//$scope.fullUrl = $scope.url + '/stcwebapp/api/login/check/'+$scope.blockchainIPAddress+'/'+$scope.blockchainPort;
			console.log('the fullURL logged user in URL is',$scope.fullUrl);
			
			
			$scope.loginDetails = {
				  "enrollId": $scope.userid,
				  "enrollSecret": $scope.pwd,
				  "flag":$scope.flag
			  };
			mainService.getLogin($scope.loginDetails,$scope.fullUrl).then(function(result){
				if (result.OK || result.ok ){
					if($scope.loggedUser.userRole == 'bank' ){
						$rootScope.prevState = 'dashboard';
						$state.go('dashboard');
					}
					else{
						$rootScope.prevState = 'dashConsumer';
						$state.go('dashConsumer');	
					}
				}
				else{
					$scope.errorFlag = true;
					$scope.error = result.error;
					return false;
				}	
			}, function(error){
				/*$scope.error="Something went wrong. Please try again later!!"*/
			});
		
			
		};
	};
}]);


/*App.controller('loginCtrl',['$scope', '$rootScope', '$state', 'mainService','sessionService','$localStorage', '$http', 
                                 function($scope ,$rootScope, $state, mainService,sessionService, $localStorage, $http){

	mainService.setAppStatus = 'h';
	$scope.flag = mainService.setAppStatus;
	
	console.log('loginFabric called');
	
	$scope.login = function(userid,pwd){
		$scope.error = "";
		$scope.LoggedUser={};
		
		$scope.ipAddress = "localhost"; //"169.254.177.230"; //"localhost";
		$scope.port = "8080";
		$scope.url = 'http://'+ $scope.ipAddress + ':' + $scope.port;
		
		$scope.fullUrl = $scope.url + '/kycapp/api/login/check';
		console.log('the fullURL logged user in URL is',$scope.fullUrl);
		
		$scope.loginDetails = {
			  "enrollId": $scope.userid,
			  "enrollSecret": $scope.pwd,
			  "flag":$scope.flag
		};
		mainService.getLogin($scope.loginDetails,$scope.fullUrl).then(function(result){
			if (result.OK || result.ok ){
				$scope.LoggedUser={
					userid:result.userName,
					bankName:result.bankName,
					serverPort : result.serverPort,
					blockChainIp: result.blockChainIpAddress,
					userRole:result.userRole,
					ipAddress: "localhost",
					port : "8080"
				}
				localStorage.setItem('loggedUser',JSON.stringify($scope.LoggedUser));
				
				var LoggedUser={
					userid:result.userName,
					bankName:result.bankName,
					serverPort : result.serverPort,
					blockChainIp: result.blockChainIpAddress,
					userRole:result.userRole,
					ipAddress: "localhost",
					port : "8080"
				}
				storing bank name in session_
				sessionService.set('loggedUser', LoggedUser);
				sessionService.set('bankName', LoggedUser.bankName);
				sessionService.set('userId', LoggedUser.userid);
				if(result.userRole == 'bank' ){
					$state.go('dashboard');
				}
				else{
					$state.go('dashConsumer');	
				}
			}
			else{
				$scope.error = result.error;
				return false;
			}	
		}, function(error){
			$scope.error="Wrong Username and Password"
		});
	};
}]);

*/