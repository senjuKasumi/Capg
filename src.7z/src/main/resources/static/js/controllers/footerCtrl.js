App.controller('footerCtrl',['$scope','$localStorage', function($scope,$localStorage){
		$scope.ipAddress = $localStorage.ipAddress;
		$scope.port = $localStorage.port;
}]);
