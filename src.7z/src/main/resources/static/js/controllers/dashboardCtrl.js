App.controller('dashboardCtrl',['$scope', '$rootScope', '$state', 'mainService','sessionService','$localStorage', '$filter', 
								function($scope, $rootScope, $state, mainService, sessionService, $localStorage, $filter){
var base64file;
//var corda = $state.params.corda;
var flag = mainService.setAppStatus;
$scope.flag = flag;
console.log("the value of corda in operationCtrl"+flag);
$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
$scope.enrollid=$scope.loggedUser.userid;
$scope.bankName = $scope.loggedUser.bankName;
$scope.userRole = $scope.loggedUser.userRole;
var serverPort =$scope.loggedUser.serverPort;
var ip = $scope.loggedUser.blockChainIp;
$scope.operationObj = {};

var userID = $scope.loggedUser.userid;
var bankNameFromSession = $scope.loggedUser.bankName;
var userIdFromSession =  sessionService.get('userId');


console.log('bankName in Session in operationCtrl',bankNameFromSession);

var ipVal = $scope.loggedUser.ipAddress;
var portVal =$scope.loggedUser.port;

$scope.reload = function(){
	 $state.reload();
}
$scope.operationlogout = function() {
	$localStorage.$reset();
};

if(flag=='c'){
	
	$scope.operationlogout = function() {
		/*$localStorage.$reset();*/
		$state.go("loginCorda");
	};
	
	$('input[type=file]').change(function () {
		
        var val = $(this).val().toLowerCase();
        var regex = new RegExp("(.*?)\.(zip)$");
        if(!(regex.test(val))) {
             document.getElementById("main").value= " ";
             //alert('Please select correct file format');
             $scope.error = 'Please Select a ZIP document.';
        }
	});
}
else{
	
	
	$scope.operationlogout = function() {
		//$localStorage.$reset();
		$state.go("loginFabric");
	};
	$('input[type=file]').change(function () {
	      var val = $(this).val().toLowerCase();
	      var regex = new RegExp("(.*?)\.(pdf)$");

	     if(!(regex.test(val))) {
	           document.getElementById("main").value= " ";
	           //alert('Please select correct file format');
	           $scope.error = 'Please Select a PDF document.';
	     }
	});
}
	
	/*-------service which initiates to get data in bubbles-------*/
		
	
	$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kyc/counts/'+$scope.bankName+'/'+userID;
	//$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/api/'+flag+'/kyc/counts/'+$scope.bankName+'/'+serverPort;

	mainService.getDetails($scope.fullUrl).then(function(result){
		if(result.error){
			console.log(result)
			$scope.error = result.error.message;
			return false;
		}
		else if (result!=null){
			    $scope.AllContracts=result.AllContracts;
				$scope.CreatedContracts=result.CreatedContracts;
				$scope.expiringContracts=result.ExpiringContracts;	
			
			}				
		}, function(error){
			$scope.error = 'Something went wrong. Please try again later.';
	});

	$scope.allKycUrl = 	'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByBankName/'+$scope.bankName+'/'+userID;
	mainService.getDetails($scope.allKycUrl).then(function(result){
		if(result.error){
			console.log(result)
			$scope.error = result.error.message;
			return false;
		}
		else if (result!=null){
			$scope.successFlag = true;
     	    $scope.users=result;	
		}				
	}, function(error){
			$scope.error = 'Something went wrong. Please try again later.';
	});
	
	
	
	$scope.expiringKyc=function(){	
	
		$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByExpiringMonth/'+$scope.bankName+'/'+userID;
		//$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/api/'+flag+'/kycByExpiringMonth/'+$scope.bankName+'/'+serverPort;
		
		mainService.getDetails($scope.fullUrl).then(function(result){
			if(result.error){
				console.log(result)
				$scope.error = result.error;
				return false;
			}
			else if (result!= null){
				
				if($scope.userRole=='bank' || $scope.userRole=='Bank'){
					/*can be sent by middle layer*/
					result.KYC_CREATE_DATE = new Date();	/* today's date when bank wants to update expiring KYC */	
				}
				
				$state.go('operationQuery',{"queryObj":result});
			}
			}, function(error){
				$scope.error = 'Something went wrong. Please try again later.';
		});
	  }
	  
	  $scope.totalKyc=function(){		  
		
		  $scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByBankName/'+$scope.bankName+'/'+userID;
		  //$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/api/'+flag+'/kycByBankName/'+$scope.bankName+'/'+serverPort;
			
		  mainService.getDetails($scope.fullUrl).then(function(result){
			if(result.error){
				console.log(result)
				$scope.error = result.error.message;
				return false;
			}
			else if (result!= null){
				$state.go('operationQuery',{"queryObj":result});
				
			}			
			}, function(error){
				$scope.error = 'Something went wrong. Please try again later.';
		 });
	  }
	  
	  $scope.viewUser = function(user){
			$scope.userId=user.USER_ID;
			$rootScope.prevState='dashboard';
			
			// $scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByUserId/'+$scope.userId+'/'+$scope.bankName+'/'+$scope.userId;			//for search via userI
			$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByUserId/'+userID+'/'+$scope.bankName+'/'+$scope.userId;			//for search via userI
			
			mainService.getDetails($scope.fullUrl).then(function(result){
				if(result.error){
					console.log(result)
					$scope.error = result.error.message;
					return false;
				}
				else if (result!= null){
					/*storing result in queryobj and sending result to operationQuery ctrl*/
					$state.go('operationQuery',{"queryObj":result});
					
				}
				}, function(error){
					$scope.error = 'Something went wrong. Please try again later.';
			});
	  }
	  
	  
	  $scope.addedKyc=function(){
			
		  $scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByCreatedMonth/'+$scope.bankName+'/'+userID;
		  //$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/api/'+flag+'/kycByCreatedMonth/'+$scope.bankName+'/'+serverPort;
			
		  	mainService.getDetails($scope.fullUrl).then(function(result){
				if(result.error){
					console.log(result)
					$scope.error = result.error.message;
					return false;
				}
				else if (result!= null){
					/*storing result in queryobj and sending result to operationQuery ctrl*/
					$state.go('operationQuery',{"queryObj":result});
					
				}
				}, function(error){
					$scope.error = 'Something went wrong. Please try again later.';
			});
		}
		  
		/*$scope.operation = opt;*/
		$scope.searchCall = function()  {
			$scope.operation = "View KYC Details";
			if($scope.operation === "Add New KYC Details"){					//doubt
				var newFile= $(":file")[0].files[0]
			    if(newFile &&(newFile.type=='application/pdf')){
			      var reader = new FileReader();
				  reader.readAsDataURL(newFile);
				  reader.onload = function () {
					  $scope.kycDoc=reader.result;
					  updateHeader()     
				  };
                }
		        else{
		        	$scope.errorFlag=true;
		        	$scope.errorMsg = 'Please Select a PDF document.';
		            $("#main").val(" ")
		            return false;
		        }
				$scope.method = "invoke"
			}
			else if($scope.operation==="View KYC Details"){
				$scope.errorFlag=false;
				$scope.method = "query"
				updateHeader()
			}																//doubt ends
				
			function updateHeader(){
				if(typeof $scope.userid== 'undefined' || $scope.userid== '' || $scope.userid== NaN)
					$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kyc/all/'+$scope.bankName+'/'+userID;						//for search all KYC
				else
					//$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByUserId/'+$scope.userid+'/'+$scope.bankName+'/'+userID;			//for search via userI
					$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByUserId/'+userID+'/'+$scope.bankName+'/'+$scope.userid;			//for search via userI
				
				mainService.getDetails($scope.fullUrl).then(function(result){
					if(result.error){
						$scope.error = result.error.message;
						return false;
					}
					else if (result != null){
						console.log(result);
						$state.go('operationQuery',{"queryObj":result});
						
					}
					}, function(error){
						$scope.error = 'Something went wrong. Please try again later.';
					});
				}		
		}
				
		$scope.clearScope = function(){
			$scope.error='';
			$scope.successMsg='';
		}
		
	   /*  $(document).on('change', '.file', function(){
	    	 $(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
	    	 $scope.kYcName=$(this).val().replace(/C:\\fakepath\\/i, '');
	    	 
	     });*/
		
	
}]);