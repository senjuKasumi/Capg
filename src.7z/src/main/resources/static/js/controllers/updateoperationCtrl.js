App.controller('updateoperationCtrl',['$scope', '$rootScope', '$http' ,'$state', '$q', 'mainService','$localStorage','$stateParams' ,'$filter', 
								function($scope, $rootScope, $http, $state, $q, mainService, $localStorage, $stateParams, $filter){
	
	var flag = mainService.setAppStatus;
	console.log("the value of flag in updateOperationCtrl",flag);
	
	$scope.queryObj= $state.params.queryObj;
	$localStorage.listObj=$scope.queryObj;
	
	
	$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
	$scope.enrollid=$scope.loggedUser.userid;
	$scope.userRole=$scope.loggedUser.userRole;
	$scope.country=$scope.loggedUser.country;

	var bankTemp = $scope.loggedUser.bankName;
	var ipVal = $scope.loggedUser.ipAddress;
	var portVal =$scope.loggedUser.port;
	var serverPort =$scope.loggedUser.serverPort;
	var ip = $scope.loggedUser.blockChainIp;

    var userID = $scope.loggedUser.userid;
	var string; 
	var user;
	
	/*$scope.id_proof_type = ["PAN", "Driving licence","Passport"];
	$scope.address_proof_type = ["Aadhar", "Electricity Bill"];*/
	$scope.other_proof_type = ["Voter ID", "Other Proof"];
	$scope.riskValues = ["High","Medium","Low"];
	
	

	$scope.docsUrl='json/documentType.json';
	mainService.getTempLogin($scope.docsUrl).then(function(result){
		if(result.Failure){
			$scope.error = result;
			return false;
		}
		else if (result){
			$scope.other_proof = result.other_proof;
			if($scope.country=='India'){
				$scope.id_proof = result.id_proof_India,	
				$scope.address_proof = result.address_proof_India
			}
			else if($scope.country=='US'){
				$scope.id_proof = result.id_proof_US,	
				$scope.address_proof = result.address_proof_US
			}
			else{
				$scope.id_proof = result.id_proof_Europe,	
				$scope.address_proof = result.address_proof_Europe
			}
		}	
	}, function(error){
		$scope.error = error;
	});
	
	
	
	$scope.bankName=$rootScope.newObj.KYC_BANK_NAME;
	$scope.userid=$rootScope.newObj.USER_ID;
	
	$scope.data = {};
	
	$scope.userName=$rootScope.newObj.USER_NAME;
	
	$scope.data.riskFactor = $rootScope.newObj.riskFactor;
	$scope.data.averageDailyTransaction = $rootScope.newObj.averageDailyTransaction;
	$scope.data.amlCheck = $rootScope.newObj.amlCheck;
	
	$scope.operation = "View KYC Details";
	$scope.status = $scope.queryObj[0].status;
    
	var itemDetail ={};
	var myToday;
	var expDate;
	var kycInfo;
	
	itemDetail.KYC_CREATE_DATE =  myToday;
	itemDetail.KYC_VALID_TILL_DATE = expDate;
	itemDetail.KYC_BANK_NAME = $rootScope.newObj.KYC_BANK_NAME;
	itemDetail.KYC_INFO = $rootScope.newObj.KYC_INFO;
	
	$scope.data.riskFactor = $scope.queryObj[0].kycRiskProfile.riskFactor; 
 	$scope.data.averageDailyTransaction = $scope.queryObj[0].kycRiskProfile.averageDailyTransaction; 
 	$scope.data.amlCheck = $scope.queryObj[0].kycRiskProfile.amlCheck;
 	
	if(flag == 'c'){
		$scope.updateCall = function(data){
			itemDetail.USER_ID = $scope.userid;
			itemDetail.USER_NAME = $scope.userName;
			itemDetail.KYC_CREATE_DATE =  $rootScope.newObj.KYC_CREATE_DATE;
            itemDetail.KYC_VALID_TILL_DATE = $rootScope.newObj.KYC_VALID_TILL_DATE;
            itemDetail.userRole = $scope.userRole;
            $scope.status = $scope.queryObj[0].status;
            
            itemDetail.status = $scope.queryObj[0].status;
	
            
            itemDetail.userAddressInfo = {};
			itemDetail.userIdentityInfo = {};
			itemDetail.userOtherDocument = {};
            itemDetail.kycRiskProfile = {};
             
            if($scope.userRole=='bank' || $scope.userRole=='Bank'){
				itemDetail.kycRiskProfile.userId = $scope.userid;
				itemDetail.kycRiskProfile.riskFactor = data.riskFactor;
				itemDetail.kycRiskProfile.averageDailyTransaction = data.averageDailyTransaction;
				itemDetail.kycRiskProfile.amlCheck = data.amlCheck;
				
				itemDetail.userOtherDocument.userId = $scope.queryObj[0].userOtherDocument.userId;
				itemDetail.userOtherDocument.documentType = $scope.queryObj[0].userOtherDocument.documentType;
				itemDetail.userOtherDocument.documentId = $scope.queryObj[0].userOtherDocument.documentId;
				itemDetail.userOtherDocument.docBlob = $scope.queryObj[0].userOtherDocument.docBlob;
				
				itemDetail.userAddressInfo.userId = $scope.queryObj[0].userAddressInfo.userId;
				itemDetail.userAddressInfo.documentType = $scope.queryObj[0].userAddressInfo.documentType;
				itemDetail.userAddressInfo.documentId = $scope.queryObj[0].userAddressInfo.documentId;
				itemDetail.userAddressInfo.docBlob = $scope.queryObj[0].userAddressInfo.docBlob;
				
				itemDetail.userIdentityInfo.userId = $scope.queryObj[0].userIdentityInfo.userId;
				itemDetail.userIdentityInfo.documentType = $scope.queryObj[0].userIdentityInfo.documentType;
				itemDetail.userIdentityInfo.documentId = $scope.queryObj[0].userIdentityInfo.documentId;
				itemDetail.userIdentityInfo.docBlob = $scope.queryObj[0].userIdentityInfo.docBlob;
				
				var apiBaseURL = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/updateKycDoc/'+userID;
				
				$http.post(apiBaseURL,itemDetail).then(function(response){
					if(response!=null){
						if($rootScope.prevState == 'dashConsumer'){
							$state.go('dashConsumer');
						}
						else{
							$state.go('dashboard');
						}
						$scope.succ = "KYC Details Updated Successfully !";
					}else{
						$scope.error = "Failed to update KYC Details !";
					}
					console.log('brought back', response);
				});
				
			}
			else{
				itemDetail.kycRiskProfile.userId = $scope.queryObj[0].kycRiskProfile.userId;
				itemDetail.kycRiskProfile.riskFactor = $scope.queryObj[0].kycRiskProfile.riskFactor; 
				itemDetail.kycRiskProfile.averageDailyTransaction = $scope.queryObj[0].kycRiskProfile.averageDailyTransaction;
				itemDetail.kycRiskProfile.amlCheck = $scope.queryObj[0].kycRiskProfile.amlCheck;
			
				itemDetail.userOtherDocument.userId = $scope.userid;
				itemDetail.userOtherDocument.documentType = data.other_proof_type;
				itemDetail.userOtherDocument.documentId = data.other_proof_number;
				
				itemDetail.userAddressInfo.userId = $scope.userid;
				itemDetail.userAddressInfo.documentType = data.address_proof_type;
				itemDetail.userAddressInfo.documentId = data.address_proof_number;
				
				itemDetail.userIdentityInfo.userId = $scope.userid;
				itemDetail.userIdentityInfo.documentType = data.id_proof_type;
				itemDetail.userIdentityInfo.documentId = data.id_proof_number;
				
				$scope.idProof= $("#id-proof")[0].files[0];
				var Proof= $("#id-proof")[0].files[0];
				$scope.idProof.category = "identity";
				
				$scope.addressProof= $("#address-proof")[0].files[0];
				var addressProof= $("#address-proof")[0].files[0];
				$scope.addressProof.category = "address";
				
				$scope.otherCategory = "other";
				if($("#other-proof")[0].files[0]){
					$scope.blob= $("#other-proof")[0].files[0];
					var blob= $("#other-proof")[0].files[0];
					itemDetail.userOtherDocument.userId = $scope.userid;
					itemDetail.userOtherDocument.documentType = data.other_proof_type;
					itemDetail.userOtherDocument.documentId = data.other_proof_number;
				}
				else{
					$scope.blob= null;
					var blob= null;
					itemDetail.userOtherDocument.userId = null;
					itemDetail.userOtherDocument.documentType = null;
					itemDetail.userOtherDocument.documentId = null;		
				}
				
				$scope.method = "invoke"
							
				$q.all([
					mainService.getBase64File($scope.idProof,$scope.idProof.category),
					mainService.getBase64File($scope.addressProof,$scope.addressProof.category),
					mainService.getBase64File($scope.blob,$scope.otherCategory) 
					]).then(function(value) {
				        // Success callback where value is an array containing the success values
				        $scope.stringID = value[0];
				        $scope.stringAddress = value[1];
				        $scope.stringOther = value[2];
				
				        itemDetail.userIdentityInfo.docBlob = $scope.stringID;
				        itemDetail.userAddressInfo.docBlob =  $scope.stringAddress;
				        itemDetail.userOtherDocument.docBlob = $scope.stringOther;
				        
						var apiBaseURL = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/updateKycDoc/'+userID;
						
						$http.post(apiBaseURL,itemDetail).then(function(response){
							if(response!=null && response.data.ok!=null){
								if($rootScope.prevState == 'dashConsumer'){
									$state.go('dashConsumer');
								}
								else{
									$state.go('dashboard');
								}
								$scope.succ = "KYC Details Updated Successfully !";
							}else{
								$scope.error = "Failed to update KYC Details !";
							}
							console.log('brought back', response);
						});
		    		}, function(reason) {
		    			// Error callback where reason is the value of the first rejected promise
			    		$scope.error = reason;
			    });
			
			}
			
		}
	}
	else{
		$scope.updateCall = function (data){
			
			itemDetail.USER_ID = $scope.userid;
			itemDetail.USER_NAME = $scope.userName;
			
			var newFile= $(":file")[0].files[0]
			if(newFile &&(newFile.type=='application/pdf')){
				 var reader = new FileReader();
				 reader.readAsDataURL(newFile);
                 reader.onload = function () {
                	 base64file=reader.result;
	    		  	 string = base64file.substring(28);
	              	 itemDetail.KYC_DOC_BLOB =  string ; 
	              	 
	              	 console.log("PDF file",itemDetail.KYC_DOC_BLOB);
                     
	              	 updateHeader()  
                 };
          }
          else{
        	  $scope.error = 'Please Select a PDF document.';
              $("#main").val(" ")
              return false;
          }
	   }
		function updateHeader(){
			var fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/updateKycDoc/'+userID;
			
				$http.post(fullUrl,itemDetail).then(function(response){
				
				if(response.ok!=null && response!=null){
					if($rootScope.prevState = 'dashConsumer'){
						$state.go('dashConsumer');
					}
					else{
						$state.go('dashboard');
					}
					$scope.succ = "KYC Details Added Successfully !";

				}else{
					$scope.err = "Failed to add KYC Details !";

				}
				//console.log('brought back', response);
				//alert("userId = "+$scope.itemDetail.userId+"userName = "+$scope.itemDetail.userName+"kycBankName = "+$scope.itemDetail.kycBankName+"kycDocBlob = "+string);
			});
			
			/*mainService.getDetails($scope.fullUrl).then(function(result){
				$scope.operation = "View KYC Details";
				if(result.error){
					$scope.error = result.error.message;
					return false;
				}
				else if (result!= null){
					if(result.id == 1){
						console.log(result)
						//$state.go('operationQuery',{updateQueryObj:"KYC Details are Updated succesfully!"});
						$state.go('operation');
					}else{
						//$state.go('operationQuery',{updateQueryObj:"KYC Details are Updated succesfully!"});
						$scope.successMsg = "KYC Details are Updated succesfully!";
					}
				}
				}, function(error){
					$scope.error = 'Something went wrong. Please try again later.';
		  });*/
	   }
	}
	
	$(document).on('change', '.file', function(){
		  
		 //$(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
		 //$scope.kYcName=$(this).val().replace(/C:\\fakepath\\/i, '');
		 
		 $("#"+this.id+"_main").val($(this).val().replace(/C:\\fakepath\\/i, ''));
		 
	});
	
   /*$(document).on('change', '.file', function(){
	  $(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
   });*/
   
	/*
		$scope.userName=$rootScope.newObj.USER_NAME;
		$scope.userid=$rootScope.newObj.USER_ID;
		$scope.bankName=$rootScope.newObj.KYC_BANK_NAME;
		$scope.operation = "View KYC Details";
		
		$scope.updateCall = function (){
			$localStorage.chaincodeId = $scope.chaincodeID;
			var newFile= $(":file")[0].files[0]
			if(newFile &&(newFile.type=='application/pdf')){
				 var reader = new FileReader();
				 reader.readAsDataURL(newFile);
                 reader.onload = function () {
                	 $scope.kycDoc=reader.result;
                     updateHeader()  
                 };
          }
          else{
        	  $scope.error = 'Please Select a PDF document.';
              $("#main").val(" ")
              return false;
          }
	   }
	 
	   function updateHeader(){
		    $scope.method="invoke"
			$scope.operationObj = {
			  "jsonrpc": "2.0",
			  "method": $scope.method,
			  "params": {
				  "type": 1,
				  "chaincodeID":{
					  "name":$scope.chaincodeID
				  },
				  "ctorMsg": {
					 "args":[]
				  },
				  "secureContext": $scope.enrollid
			  },
			  "id": ''
			}
			$scope.operationObj.params.ctorMsg.args.push("UpdateKycDetails",$scope.userid,$scope.userName,$scope.kycDoc);
			$scope.operationObj.id = 1;			
			$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/chaincode';
			mainService.getDetails($scope.operationObj, $scope.fullUrl).then(function(result){
				$scope.operation = "View KYC Details";
				if(result.error){
					$scope.error = result.error.message;
					return false;
				}
				else if (result.result.status == 'OK'){
					if(result.id == 1){
						console.log(result)
						//$state.go('operationQuery',{updateQueryObj:"KYC Details are Updated succesfully!"});
						$state.go('operation');
					}else{
						//$state.go('operationQuery',{updateQueryObj:"KYC Details are Updated succesfully!"});
						$scope.successMsg = "KYC Details are Updated succesfully!";
					}
				}
				}, function(error){
					$scope.error = 'Something went wrong. Please try again later.';
			});
			
	   }
	   $(document).on('change', '.file', function(){
    	  $(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
      });
	*/
}]);