App.controller('dashConsumerCtrl',['$scope', '$rootScope', '$state', 'mainService','sessionService','$localStorage', '$filter', 
								function($scope, $rootScope, $state, mainService, sessionService, $localStorage, $filter){
var base64file;
//var corda = $state.params.corda;
var flag = mainService.setAppStatus;
$scope.flag = flag;
console.log("the value of corda in operationCtrl"+flag);
$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
$scope.enrollid=$scope.loggedUser.userid;
$scope.bankName = $scope.loggedUser.bankName;
$scope.userRole = $scope.loggedUser.userRole;
var serverPort =$scope.loggedUser.serverPort;
var ip = $scope.loggedUser.blockChainIp;
$scope.operationObj = {};
$scope.userid = $scope.loggedUser.userid;

//console.log('bankName in Session in operationCtrl',bankNameFromSession);

var ipVal = $scope.loggedUser.ipAddress;
var portVal =$scope.loggedUser.port;

$scope.reload = function(){
	 $state.reload();
}
$scope.operationlogout = function() {
	$localStorage.$reset();
};

$scope.valueit=function(index,item,queryObj){
	$rootScope.newObj=item;
	$rootScope.prevState = 'dashConsumer';
	$state.go('update',{"queryObj":queryObj});
};

	if(flag == 'c'){
		   /*$scope.downloadPDF = function(i) {
			   var KYC_DOC = $scope.queryObj[i].KYC_DOC_BLOB;
			   
			  $scope.fullUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+KYC_DOC;

			   //$scope.fullUrl = 'http://'+ipVal+':10007/attachments/'+KYC_DOC;
			   
			 
	            var element = document.createElement('a');
				element.setAttribute('href',$scope.fullUrl);
	            //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.queryObj[i].KYC_DOC_BLOB));
				//element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.queryObj[i].KYC_DOC_BLOB));
		        element.setAttribute('download',"attachment.zip");
	            element.style.display = 'none';
	            document.body.appendChild(element);
	            element.click();
	            document.body.removeChild(element); 
	          
	  	   };*/
		  	$scope.operationlogout = function() {
		 		/*$localStorage.$reset();*/
		 		$state.go("loginCorda");
		 	};
		 	
		 	$scope.downloadID = function(i) {
				   //var userIdentityInfo = $scope.queryObj[i].userIdentityInfo;
				   var userInfo = $scope.queryObj[i];
				   
				   //$scope.identityInfoUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userIdentityInfo;
				   //$scope.identityInfoUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/identity';			//for getting doc blob of identity document
					var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userIdentityInfo/' + userInfo.userIdentityInfo.docBlob;
				   /*mainService.getTempDetails( userIdentityInfo,$scope.identityInfoUrl).then(function(result){
					   //if(result.status=='success'){
						  $scope.docBlob = result.docBase64;

						  var element = document.createElement('a');
                        //element.setAttribute('href',$scope.identityInfoUrl);
                        //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.docBlob));
                        element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                        element.setAttribute('download',"userIdentityInfo.zip");
                        element.style.display = 'none';
                        document.body.appendChild(element);
                        element.click();
                        document.body.removeChild(element);
					   *//*}
					   else{
						   $scope.error = 'Something went wrong in fetching the attachment.';
							return false; 
					   }*//*
				   },function(error){
					   $scope.error = 'Something went wrong. Please try again later.';
				   })*/
				   return href;

		  };
	  	   
	  	   $scope.downloadAddressProof = function(i){

			   var userInfo = $scope.queryObj[i];
			   
			  // $scope.addressInfoUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userAddressInfo;
			  
			   //$scope.addressInfoUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/address';			//for getting doc blob of address document
				var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userAddressInfo/' + userInfo.userAddressInfo.docBlob;
			   /*mainService.getTempDetails(userAddressInfo,$scope.addressInfoUrl).then(function(result){
				   if(result.status=='success'){
					  $scope.docBlob = result.docBase64;
					  var element = document.createElement('a');
                    //element.setAttribute('href',$scope.addressInfoUrl);
                    //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.queryObj[i].docBlob));
                    element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                    element.setAttribute('download',"userAddressInfo.zip");
                    element.style.display = 'none';
                    document.body.appendChild(element);
                    element.click();
                    document.body.removeChild(element);
				   }
				   else{
					   $scope.error = 'Something went wrong in fetching the attachment.';
						return false; 
				   }
			   },function(error){
				   $scope.error = 'Something went wrong. Please try again later.';
			   })*/

	          return href;
	  	   }
	  	   
	  	   $scope.downloadOtherProof = function(i){

	 		  var userInfo = $scope.queryObj[i];
	 		   
	 		 // $scope.otherDocumentUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userOtherDocument;
	 		  
	 		  //$scope.otherDocumentUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/other';			//for getting doc blob of other document
	 		  var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userOtherDocument/' + userInfo.userOtherDocument.docBlob;
	 			
	 		   /*mainService.getTempDetails(userOtherDocument,$scope.otherDocumentUrl).then(function(result){
	 			   if(result.status=='success'){
	 				  $scope.docBlob = result.docBase64;
	 				  var element = document.createElement('a');
                      //element.setAttribute('href',$scope.otherDocumentUrl);
                       //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.queryObj[i].docBlob));
                      element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                      element.setAttribute('download',"userOtherDocument.zip");
                       element.style.display = 'none';
                       document.body.appendChild(element);
                       element.click();
                       document.body.removeChild(element);
	 			   }
	 			   else{
	 				   $scope.error = 'Something went wrong in fetching the attachment.';
	 					return false; 
	 			   }
	 		   },function(error){
	 			   $scope.error = 'Something went wrong. Please try again later.';
	 		   })*/
	 		   return href;

	 	   }
		 	
		 	
		 	
		 	/*$('input[type=file]').change(function () {
		 		
		         var val = $(this).val().toLowerCase();
		         var regex = new RegExp("(.*?)\.(zip)$");
		         if(!(regex.test(val))) {
		              document.getElementById("main").value= " ";
		              //alert('Please select correct file format');
		              $scope.error = 'Please Select a ZIP document.';
		         }
		 	});*/
		}
		else{
		   $scope.downloadPDF = function(i) {
	           /*var dlnk = document.getElementById('dwnldLnk');
	           dlnk.href = $scope.queryObj[i].KYC_DOC_BLOB;*/
	           /*dlnk.click();*/
	           
	           var element = document.createElement('a');
	           element.setAttribute('href','data:application/pdf;base64,'+ encodeURIComponent($scope.queryObj[i].KYC_DOC_BLOB));
	           element.setAttribute('download',"attachment.pdf");
	           element.style.display = 'none';
	           document.body.appendChild(element);
	           element.click();
	           document.body.removeChild(element);
	                    
	       };
	       $scope.operationlogout = function() {
	   		//$localStorage.$reset();
	    	   $state.go("loginFabric");
		   	};
		   	$('input[type=file]').change(function () {
		   	      var val = $(this).val().toLowerCase();
		   	      var regex = new RegExp("(.*?)\.(pdf)$");
	
		   	     if(!(regex.test(val))) {
		   	           document.getElementById("main").value= " ";
		   	           //alert('Please select correct file format');
		   	           $scope.error = 'Please Select a PDF document.';
		   	     }
		   	});
	   }


		$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/kycByUserId/'+$scope.userid+'/'+$scope.bankName+'/'+$scope.userid;			//for search via userI
		
		mainService.getDetails($scope.fullUrl).then(function(result){
			if(result.error){
				$scope.error = result.error.message;
				return false;
			}
			else if (result != null){
				console.log(result);
				$scope.noDataFound = false;
				$scope.queryObj = result;
			}
		}, function(error){
			$scope.error = 'Something went wrong. Please try again later.';
		});
					
		
		
		if($scope.queryObj == 'No Records Found' || $scope.queryObj == null || $scope.queryObj == '' ){
			$scope.noDataFound = true;
		}
		
		$scope.clearScope = function(){
			$scope.error='';
			$scope.successMsg='';
		}
		
	 /*    $(document).on('change', '.file', function(){
	    	 $(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
	    	 $scope.kYcName=$(this).val().replace(/C:\\fakepath\\/i, '');
	    	 
	     });*/
		
	
}]);