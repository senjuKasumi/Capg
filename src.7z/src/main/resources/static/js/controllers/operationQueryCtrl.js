App.controller('operationQueryCtrl',['$scope', '$rootScope', '$state', 'mainService','$localStorage', '$http',function($scope, $rootScope, $state, mainService,$localStorage,$http){
	$scope.result=false;
	
	$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'));
	var flag = mainService.setAppStatus;
	console.log("the value of flag in operationQueryCtrl",flag);
	$scope.flag=flag;
   	$scope.updateQueryObj = $state.params.updateQueryObj;
   	var ipVal = $scope.loggedUser.ipAddress;
	var portVal =$scope.loggedUser.port;
	var serverPort = $scope.loggedUser.serverPort;
	//$scope.queryObj= JSON.parse($state.params.queryObj);
	$scope.queryObj= $state.params.queryObj;
	$scope.userRole = $scope.loggedUser.userRole;
	$scope.bankName = $scope.loggedUser.bankName;
	
	
	var userID = $scope.loggedUser.userid;
	// To get list of users on back button 
	$scope.route=$state.params.listRoute;
				
	if($scope.route==true){
		$scope.queryObj=$localStorage.listObj;
		$scope.route==false;
	}
	
	if($scope.queryObj == 'No Records Found' || $scope.queryObj == null || $scope.queryObj == '' ){
		$scope.noDataFound = true;
	}
	
	$scope.valueit=function(index,item,queryObj){
		$rootScope.newObj=item;
		
		$state.go('update',{"queryObj":queryObj});
	};
	
	var itemDetail ={};
	
	//$scope.status = $scope.queryObj[i].status;
	
   	$scope.updateComplaint = function(i){
   		itemDetail = $scope.queryObj[i];
   		itemDetail.userRole = 'bank';
   		itemDetail.status = 'approve';
   		var apiBaseURL = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/updateKycDoc/'+userID;
		
		$http.post(apiBaseURL,itemDetail).then(function(response){
			if(response!=null){
				$state.go('dashboard');
				$scope.succ = "KYC Details Updated Successfully !";
			}else{
				$scope.error = "Failed to update KYC Details !";
			}
			console.log('brought back', response);
		});
   	} 
	
   	$scope.updateNONComplaint = function(i){
   		itemDetail = $scope.queryObj[i];
   		itemDetail.userRole = 'bank';
   		itemDetail.status = 'reject';
   		var apiBaseURL = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/updateKycDoc/'+userID;
		
		$http.post(apiBaseURL,itemDetail).then(function(response){
			if(response!=null){
				$state.go('dashboard');
				$scope.succ = "KYC Details Updated Successfully !";
			}else{
				$scope.error = "Failed to update KYC Details !";
			}
			console.log('brought back', response);
		});
   	}
	
   	if(flag == 'c'){
	   $scope.downloadID = function(i) {
		   var userInfo = $scope.queryObj[i];

		   //$scope.identityInfoUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userIdentityInfo;
		   //$scope.identityInfoUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/identity';			//for getting doc blob of identity document


			//var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userIdentityInfo/' + userInfo.userIdentityInfo.docBlob;
		   var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userID + '/userIdentityInfo/' + userInfo.userIdentityInfo.docBlob;
			//{flag}/downloadDoc/{userId}/{docName}/{docHash}

		   /*mainService.getTempDetails( userIdentityInfo,$scope.identityInfoUrl).then(function(result){
			   //if(result.status=='success'){
				  $scope.docBlob = result.docBase64;

                    var element = document.createElement('a');
                    //element.setAttribute('href',$scope.identityInfoUrl);
                    //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.docBlob));
                    element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                    element.setAttribute('download',"userIdentityInfo.zip");
                    element.style.display = 'none';
                    document.body.appendChild(element);
                    element.click();
                    document.body.removeChild(element);
			   *//*}
			   else{
				   $scope.error = 'Something went wrong in fetching the attachment.';
					return false; 
			   }*//*
		   },function(error){
			   $scope.error = 'Something went wrong. Please try again later.';
		   })*/

		   return href;
  	   };
  	   
  	   $scope.downloadAddressProof = function(i){

		   var userInfo = $scope.queryObj[i];
		   //console.log('operationQueryCtrl, line 110, userAddressInfo', userAddressInfo);
		  // $scope.addressInfoUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userAddressInfo;
		  
		   //$scope.addressInfoUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/address';			//for getting doc blob of address document
		   
		   //var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userAddressInfo/' + userInfo.userAddressInfo.docBlob;
		   var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userID + '/userAddressInfo/' + userInfo.userAddressInfo.docBlob;
			
		   /*console.log('operationQueryCtrl, line 114, addressInfoUrl', $scope.addressInfoUrl);
		   mainService.getTempDetails(userAddressInfo,$scope.addressInfoUrl).then(function(result){
			   if(result.status=='success'){
				  $scope.docBlob = result.docBase64;
				  var element = document.createElement('a');
                //element.setAttribute('href',$scope.addressInfoUrl);
                  //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.queryObj[i].docBlob));
                element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                element.setAttribute('download',"userAddressInfo.zip");
                  element.style.display = 'none';
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
			   }
			   else{
				   $scope.error = 'Something went wrong in fetching the attachment.';
					return false; 
			   }
		   },function(error){
			   $scope.error = 'Something went wrong. Please try again later.';
		   })*/
		   return href;

  	   }
  	   
  	   $scope.downloadOtherProof = function(i){

		  var userInfo = $scope.queryObj[i];
		   //console.log('operationQueryCtrl, line 146, userOtherDocument', $scope.userOtherDocument);
		 // $scope.otherDocumentUrl = 'http://'+ipVal+':'+serverPort+'/attachments/'+userOtherDocument;
		  
		  //$scope.otherDocumentUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/other';			//for getting doc blob of other document
		  //var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userInfo.USER_ID + '/userOtherDocument/' + userInfo.userOtherDocument.docBlob;
		  var href = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/downloadDoc/' + userID + '/userOtherDocument/' + userInfo.userOtherDocument.docBlob;
		  
			/*console.log('operationQueryCtrl, line 146, otherDocumentUrl', $scope.otherDocumentUrl);
		   mainService.getTempDetails(userOtherDocument,$scope.otherDocumentUrl).then(function(result){
			   if(result.status=='success'){
				  $scope.docBlob = result.docBase64;
				  var element = document.createElement('a');
                  //element.setAttribute('href',$scope.otherDocumentUrl);
                    //element.setAttribute('href','data:application/octet-stream,'+ encodeURIComponent($scope.queryObj[i].docBlob));
                  element.setAttribute('href','data:application/x-zip-compressed;base64,'+ encodeURIComponent($scope.docBlob));
                  element.setAttribute('download',"userOtherDocument.zip");
                    element.style.display = 'none';
                    document.body.appendChild(element);
                    element.click();
                    document.body.removeChild(element);
			   }
			   else{
				   $scope.error = 'Something went wrong in fetching the attachment.';
					return false; 
			   }
		   },function(error){
			   $scope.error = 'Something went wrong. Please try again later.';
		   })*/
		   return href;

	   }
  	   
	}
	else{
	   $scope.downloadID = function(i) {
           /*var dlnk = document.getElementById('dwnldLnk');
           dlnk.href = $scope.queryObj[i].KYC_DOC_BLOB;*/
           /*dlnk.click();*/
           
           var element = document.createElement('a');
           element.setAttribute('href','data:application/pdf;base64,'+ encodeURIComponent($scope.queryObj[i].KYC_DOC_BLOB));
           element.setAttribute('download',"attachment.pdf");
           element.style.display = 'none';
           document.body.appendChild(element);
           element.click();
           document.body.removeChild(element);
                    
       };
   }
       
}]);