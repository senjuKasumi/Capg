App.controller('headerCtrl',['$scope',  '$rootScope', '$state', '$localStorage','mainService', function($scope,  $rootScope, $state, $localStorage,mainService){
	
	var flag = mainService.setAppStatus;
	$scope.userRole = $scope.loggedUser.userRole;
	$scope.enrollid=$scope.loggedUser.userid;
	$scope.userName=$scope.loggedUser.userName;
	$scope.prevState = $rootScope.prevState;
	if(flag=='c'){
		$rootScope.logout = function() {
			
			// changes made by Ahmed
			// Invoking the server to invalidate the session of the user out of it.
			console.log("logged in User >> "+$scope.loggedUser.userid);
			var ipVal = $scope.loggedUser.ipAddress;
			var portVal =$scope.loggedUser.port;
			$scope.fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/login/logout/'+flag+'/'+$scope.enrollid;
			mainService.setLogout($scope.fullUrl).then(function(result){
				if(result.error){
					$scope.error = result.error.message;
					return false;
				} else if (result != null){
					console.log(result);
					
					$localStorage.$reset();
					$state.go("loginCorda");
				}
			}, function(error){
				$scope.error = 'Something went wrong. Please try again later.';
			});
			// end of changes made by Ahmed
			
			/*$localStorage.$reset();
			$state.go("loginCorda");*/
		};
	}
	else{
		$rootScope.logout = function() {
			$localStorage.$reset();
			$state.go("loginFabric");
		};
	}
	
	$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
	$scope.bankName=$scope.loggedUser.bankName;
	$rootScope.currentState = $state.current.name;
	
}]);