App.controller('addKycCtrl',['$scope', '$rootScope', '$state', '$q', '$http','mainService','sessionService','$localStorage', '$filter','cordaStatus',
								function($scope, $rootScope, $state, $q, $http, mainService, sessionService, $localStorage, $filter, cordaStatus){
var base64file;

var flag = mainService.setAppStatus;
console.log("the value of corda in addKYCCtrl"+flag);


var string; 

$scope.loggedUser=JSON.parse(localStorage.getItem('loggedUser'))
$scope.country=$scope.loggedUser.country;

var bankTemp = $scope.loggedUser.bankName;
var ipVal = $scope.loggedUser.ipAddress;
var portVal =$scope.loggedUser.port;
var serverPort =$scope.loggedUser.serverPort;
var ip = $scope.loggedUser.blockChainIp;

$scope.docsUrl='json/documentType.json';
mainService.getTempLogin($scope.docsUrl).then(function(result){
	if(result.Failure){
		$scope.error = result;
		return false;
	}
	else if (result){
		$scope.other_proof = result.other_proof;
		if($scope.country=='India'){
			$scope.id_proof = result.id_proof_India,	
			$scope.address_proof = result.address_proof_India
		}
		else if($scope.country=='US'){
			$scope.id_proof = result.id_proof_US,	
			$scope.address_proof = result.address_proof_US
		}
		else{
			$scope.id_proof = result.id_proof_Europe,	
			$scope.address_proof = result.address_proof_Europe
		}
	}	
}, function(error){
	$scope.error = error;
});

/*$scope.id_proof_India = ["PAN", "Driving licence","Passport"];
$scope.id_proof_US = ["PAN_US", "Driving licence","Passport"];
$scope.id_proof_Europe = ["PAN_Europe", "Driving licence","Passport"];

$scope.address_proof_India = ["Aadhar", "Electricity Bill"];
$scope.address_proof_US = ["House_proof", "Electricity Bill"];
$scope.address_proof_Europe = ["Rent Agreement", "Electricity Bill"];
*/
$scope.other_proof_type = ["Voter ID", "Other Proof"];



$scope.updateQueryObj = $state.params.updateQueryObj;
$scope.enrollid=$scope.loggedUser.userid;
$scope.userName=$scope.loggedUser.userName;
$scope.userid = $scope.enrollid;
$scope.userRole = $scope.loggedUser.userRole;
$scope.bankName=$scope.loggedUser.bankName;
$scope.operation= "Add New KYC Details" ;

var userID = $scope.loggedUser.userid;


var itemDetail ={};
var myToday;
var expDate;


itemDetail.KYC_CREATE_DATE =  myToday;
itemDetail.KYC_VALID_TILL_DATE = expDate;
itemDetail.KYC_BANK_NAME = $scope.loggedUser.bankName;


if(flag=='c'){
	$scope.addCall = function(data) {
		
		itemDetail.USER_ID = $scope.userid;
		itemDetail.USER_NAME = $scope.userName;
		itemDetail.KYC_INFO = data.accNum;
		itemDetail.status = 'KYC_INITIATED';
		itemDetail.userAddressInfo = {};
		itemDetail.userIdentityInfo = {};
		itemDetail.userOtherDocument = {};
		itemDetail.kycRiskProfile = {};
		
		itemDetail.userAddressInfo.userId = $scope.userid;
		itemDetail.userAddressInfo.documentType = data.address_proof_type;
		itemDetail.userAddressInfo.documentId = data.address_proof_number;
		
		itemDetail.userIdentityInfo.userId = $scope.userid;
		itemDetail.userIdentityInfo.documentType = data.id_proof_type;
		itemDetail.userIdentityInfo.documentId = data.id_proof_number;
		
		itemDetail.kycRiskProfile.userId = null;
		itemDetail.kycRiskProfile.riskFactor = null;
		itemDetail.kycRiskProfile.averageDailyTransaction = null; 
		itemDetail.kycRiskProfile.amlCheck = null;
	
		
		$scope.idProof= $("#id-proof")[0].files[0];
		var Proof= $("#id-proof")[0].files[0];
		$scope.idCategory = "identity";
		
		
		$scope.addressProof= $("#address-proof")[0].files[0];
		var addressProof= $("#address-proof")[0].files[0];
		$scope.addressCategory = "address";
		
		$scope.otherCategory = "other";
		if($("#other-proof")[0].files[0]){
			$scope.blob= $("#other-proof")[0].files[0];
			var blob= $("#other-proof")[0].files[0];
			itemDetail.userOtherDocument.userId = $scope.userid;
			itemDetail.userOtherDocument.documentType = data.other_proof_type;
			itemDetail.userOtherDocument.documentId = data.other_proof_number;
		}
		else{
			$scope.blob= null;
			var blob= null;
			itemDetail.userOtherDocument.userId = null;
			itemDetail.userOtherDocument.documentType = null;
			itemDetail.userOtherDocument.documentId = null;		
		}
		
		$scope.method = "invoke"
		
		
		
		$q.all([
            mainService.getBase64File($scope.idProof,$scope.idCategory),
            mainService.getBase64File($scope.addressProof,$scope.addressCategory),
            mainService.getBase64File($scope.blob,$scope.otherCategory) 
        ]).then(function(value) {
		        // Success callback where value is an array containing the success values
		        $scope.stringID = value[0];
		        $scope.stringAddress = value[1];
		        $scope.stringOther = value[2];
		
		        itemDetail.userIdentityInfo.docBlob = $scope.stringID;
		        itemDetail.userAddressInfo.docBlob =  $scope.stringAddress;
		        itemDetail.userOtherDocument.docBlob = $scope.stringOther;
		        
		        var apiBaseURL = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/createKycDoc/'+userID;
				
				$http.post(apiBaseURL,itemDetail).then(function(response){
					if(response!=null && response.data.ok!=null){
						$state.go('dashConsumer');
						$scope.succ = "KYC Details Added Successfully !";
					}
					else if(response.data.error){
						$scope.error = response.data.error;
					}else{
						$scope.error = "Failed to add KYC Details !";
					}
					console.log('brought back', response);
				});
    		}, function(reason) {
    			// Error callback where reason is the value of the first rejected promise
	    		$scope.error = reason;
	    });
		
			
	}

	/* $('input[type=file]').change(function () {
        var val = $(this).val().toLowerCase();
        var regex = new RegExp("(.*?)\.(zip)$");
        if(!(regex.test(val))) {
           document.getElementById("main").value= " ";
           //alert('Please select correct file format');
           $scope.error = 'Please Select a ZIP document.';
        }	
	  });*/
}

else{
	
	$scope.addCall = function(data) {		
		itemDetail.USER_ID = $scope.userid;
		itemDetail.USER_NAME = $scope.userName;
		itemDetail.KYC_INFO = $scope.accNum;
		
		if($scope.operation=== "Add New KYC Details"){
			var newFile= $(":file")[0].files[0]
			 
			if(newFile &&(newFile.type=='application/pdf')){
			      var reader = new FileReader();
				  reader.readAsDataURL(newFile);
  
				  reader.onload = function () {
            	     base64file=reader.result;
	    		  	 string = base64file.substring(28);
	              	 //itemDetail.docBlob =  string ; 
	              	
	          //    	 console.log("PDF file",itemDetail.docBlob);
              
	              	 updateHeader()     
				  };
	        }
	        else{
	        	$scope.errorFlag=true;
	        	$scope.errorMsg = 'Please Select a PDF document.';
	            $("#id-proof_main").val(" ");
	            $("#address-proof_main").val(" ");
	            $("#other-proof_main").val(" ")
	            return false;
	        }
			$scope.method = "invoke"
		
	}
		
	function updateHeader(){
		var fullUrl = 'http://'+ipVal+':'+portVal+'/kycapp/api/'+flag+'/createKycDoc/'+userID;
		//var fullUrl = 'http://'+ipVal+':'+portVal+'/api/'+flag+'/createKycDoc'+'/'+serverPort;

		$http.post(fullUrl,itemDetail).then(function(response){
			if(response!=null && response.ok!=null){
				$state.go('dashConsumer');			
				$scope.succ = "KYC Details Added Successfully !";
			}else{
				$scope.error = "Failed to add KYC Details !";
			}
			console.log('brought back', response);
		},function(error){
			$scope.error = 'Something went wrong. Please try again later.';
		});
		
		}
	
	}
		
	
	/*$('input[type=file]').change(function () {	
	    var val = $(this).val().toLowerCase();
        var regex = new RegExp("(.*?)\.(pdf)$");
            if(!(regex.test(val))) {
               document.getElementById("main").value= " ";
               //alert('Please select correct file format');
               $scope.error = 'Please Select a PDF document.';
               console.log('hyperledger code for PDF');
            }
	  });
	}*/

	$scope.clearScope = function(){
		$scope.error='';
		$scope.successMsg='';
	}

}
	
	$(document).on('change', '.file', function(){
		  
		 //$(".inputfile").find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
		 //$scope.kYcName=$(this).val().replace(/C:\\fakepath\\/i, '');
		 
		 $("#"+this.id+"_main").val($(this).val().replace(/C:\\fakepath\\/i, ''));
		 
	});
}]);




